# Quanta AI Platform - LEGO Assembly Guide

Welcome! This package contains all components needed to build the complete Quanta AI enterprise platform. Follow this guide step-by-step to assemble your system.

## 📦 Package Structure

```
quanta_platform_package/
├── SETUP/                    # Step 1: Initial Setup
├── BACKEND/                  # Step 2: Backend Services
├── DATABASE/                 # Step 3: Database Schema
├── FRONTEND/                 # Step 4: Frontend Components
├── CONFIG/                   # Step 5: Configuration Files
├── DOCUMENTATION/            # Step 6: API & Setup Docs
└── ASSEMBLY_GUIDE.md        # This file
```

## 🚀 Quick Start (5 Minutes)

### Step 1: Setup Environment
```bash
cd SETUP
bash install_dependencies.sh
```

### Step 2: Configure Database
```bash
cd ../DATABASE
# Review schema.sql and run migrations
```

### Step 3: Start Backend
```bash
cd ../BACKEND
npm install
npm run dev
```

### Step 4: Start Frontend
```bash
cd ../FRONTEND
npm install
npm run dev
```

### Step 5: Access the Platform
- Landing Page: http://localhost:3000
- Chat Interface: http://localhost:3000/app
- Admin Dashboard: http://localhost:3000/admin
- Founder Control: http://localhost:3000/founder

---

## 📋 Detailed Assembly Instructions

### LAYER 1: SETUP (5 min)
**Purpose**: Prepare your environment

**Files**:
- `install_dependencies.sh` - Install Node.js, npm, pnpm
- `environment_template.env` - Copy to `.env` and fill in values
- `system_requirements.txt` - Verify your system meets requirements

**Actions**:
1. Run the installer script
2. Copy environment template and configure
3. Verify Node.js and npm versions

---

### LAYER 2: BACKEND (15 min)
**Purpose**: Set up the AI orchestration engine and API

**Files**:
- `package.json` - Backend dependencies
- `tsconfig.json` - TypeScript configuration
- `server/routers.ts` - tRPC API procedures
- `server/db.ts` - Database helpers
- `server/quanta-orchestrator.ts` - AI engine integration
- `server/quanta.test.ts` - Backend tests

**Actions**:
1. Navigate to BACKEND directory
2. Run `npm install`
3. Run `npm run dev` to start dev server (port 5000)
4. Run `npm test` to verify all tests pass

**Key Endpoints**:
- POST `/api/trpc/quanta.processQuery` - Submit AI query
- GET `/api/trpc/quanta.getQueryHistory` - Retrieve history
- GET `/api/trpc/quanta.getMetrics` - System metrics

---

### LAYER 3: DATABASE (10 min)
**Purpose**: Initialize data persistence layer

**Files**:
- `schema.sql` - Complete database schema
- `migrations/` - Migration scripts
- `seed_data.sql` - Sample data for testing

**Actions**:
1. Create MySQL/TiDB database
2. Run `schema.sql` to create tables
3. Run migrations in order
4. (Optional) Load seed data for testing

**Tables Created**:
- `users` - User accounts and authentication
- `queries` - Stored user queries
- `responses` - AI responses and metadata
- `execution_traces` - Reasoning traces
- `metrics` - System performance data

---

### LAYER 4: FRONTEND (15 min)
**Purpose**: Build the user-facing interface

**Files**:
- `client/src/App.tsx` - Main application router
- `client/src/pages/Landing.tsx` - Public marketing website
- `client/src/pages/QuantaChatPremium.tsx` - Chat interface
- `client/src/pages/AdminDashboardPremium.tsx` - Admin dashboard
- `client/src/pages/FounderControlPanel.tsx` - Founder controls
- `client/src/index.css` - Premium dark theme
- `client/src/lib/trpc.ts` - API client configuration

**Actions**:
1. Navigate to FRONTEND directory
2. Run `npm install`
3. Run `npm run dev` to start dev server (port 3000)
4. Open http://localhost:3000 in browser

**Key Pages**:
- `/` - Public landing page
- `/app` - Chat interface (requires login)
- `/admin` - Admin dashboard (admin only)
- `/founder` - Founder control panel (founder only)

---

### LAYER 5: CONFIGURATION (5 min)
**Purpose**: Connect all layers together

**Files**:
- `.env.local` - Local environment variables
- `vite.config.ts` - Frontend build configuration
- `drizzle.config.ts` - Database ORM configuration
- `tsconfig.json` - TypeScript settings

**Key Variables**:
```
DATABASE_URL=mysql://user:password@localhost:3306/quanta
JWT_SECRET=your_secret_key_here
VITE_APP_TITLE=Quanta AI
VITE_APP_LOGO=https://...
```

---

### LAYER 6: DOCUMENTATION (Reference)
**Purpose**: API reference and troubleshooting

**Files**:
- `API_REFERENCE.md` - Complete API documentation
- `TROUBLESHOOTING.md` - Common issues and solutions
- `ARCHITECTURE.md` - System design overview
- `DEPLOYMENT.md` - Production deployment guide

---

## 🔧 Troubleshooting

### Port Already in Use
```bash
# Find process using port 3000
lsof -i :3000
# Kill it
kill -9 <PID>
```

### Database Connection Failed
```bash
# Verify MySQL is running
mysql -u root -p
# Check DATABASE_URL in .env
```

### Frontend Not Loading
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run dev
```

---

## 📊 Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│          PUBLIC LANDING PAGE (/)                    │
│  - Hero Section                                     │
│  - Capability Showcase                              │
│  - Pricing & Use Cases                              │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│       USER APPLICATION (/app)                       │
│  - Chat Interface                                   │
│  - Query History                                    │
│  - Execution Traces                                 │
│  - Admin Dashboard                                  │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│    BACKEND API (tRPC)                               │
│  - Query Processing                                 │
│  - Rate Limiting                                    │
│  - Authentication                                   │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│   QUANTA AI ORCHESTRATOR                            │
│  - Multi-Intelligence Reasoning                     │
│  - Execution Tracing                                │
│  - Quality Evaluation                               │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│       DATABASE LAYER                                │
│  - User Data                                        │
│  - Query History                                    │
│  - Metrics & Analytics                              │
└─────────────────────────────────────────────────────┘
```

---

## ✅ Verification Checklist

- [ ] All dependencies installed
- [ ] Database created and migrations run
- [ ] Backend tests passing (10/10)
- [ ] Backend server running on port 5000
- [ ] Frontend server running on port 3000
- [ ] Landing page loads at http://localhost:3000
- [ ] Can submit query in chat interface
- [ ] Admin dashboard shows metrics
- [ ] Founder panel accessible with admin account

---

## 🎯 Next Steps

1. **Customize Branding**: Edit `client/src/index.css` for colors and fonts
2. **Add Your Content**: Update landing page copy in `client/src/pages/Landing.tsx`
3. **Configure Authentication**: Set up OAuth in `server/_core/oauth.ts`
4. **Deploy**: Follow `DEPLOYMENT.md` for production setup
5. **Monitor**: Use founder dashboard to track system health

---

## 📞 Support

For issues or questions:
1. Check `TROUBLESHOOTING.md`
2. Review `API_REFERENCE.md` for endpoint details
3. Check backend logs: `npm run dev` output
4. Check frontend console: Browser DevTools

---

**Version**: 1.0.0  
**Last Updated**: March 2026  
**Status**: Production Ready
