import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  BarChart3,
  TrendingUp,
  Users,
  Zap,
  ArrowLeft,
  Activity,
  Brain,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface MetricCard {
  label: string;
  value: string | number;
  change?: string;
  icon: React.ReactNode;
  status: "good" | "warning" | "critical";
}

export default function AdminDashboardPremium() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Mock data for demonstration
  const metrics: MetricCard[] = [
    {
      label: "Total Queries",
      value: "2,847",
      change: "+12% from last week",
      icon: <Zap className="h-6 w-6" />,
      status: "good",
    },
    {
      label: "Active Users",
      value: "342",
      change: "+5% from last week",
      icon: <Users className="h-6 w-6" />,
      status: "good",
    },
    {
      label: "Avg Response Time",
      value: "1.2s",
      change: "-8% improvement",
      icon: <Activity className="h-6 w-6" />,
      status: "good",
    },
    {
      label: "System Health",
      value: "98.5%",
      change: "Optimal",
      icon: <CheckCircle className="h-6 w-6" />,
      status: "good",
    },
  ];

  const queryVolumeData = [
    { name: "Mon", queries: 400 },
    { name: "Tue", queries: 520 },
    { name: "Wed", queries: 480 },
    { name: "Thu", queries: 610 },
    { name: "Fri", queries: 720 },
    { name: "Sat", queries: 580 },
    { name: "Sun", queries: 450 },
  ];

  const moduleUsageData = [
    { name: "Linguistic", value: 28, color: "#FF4F00" },
    { name: "Logical-Math", value: 22, color: "#FF6B1F" },
    { name: "Statistical", value: 18, color: "#FF8A3D" },
    { name: "Spatial", value: 15, color: "#FFA85C" },
    { name: "Other", value: 17, color: "#666666" },
  ];

  const confidenceScoreData = [
    { range: "0-20%", count: 45 },
    { range: "20-40%", count: 120 },
    { range: "40-60%", count: 280 },
    { range: "60-80%", count: 450 },
    { range: "80-100%", count: 1200 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "good":
        return "text-green-500";
      case "warning":
        return "text-yellow-500";
      case "critical":
        return "text-red-500";
      default:
        return "text-primary";
    }
  };

  const getStatusBgColor = (status: string) => {
    switch (status) {
      case "good":
        return "bg-green-500/10";
      case "warning":
        return "bg-yellow-500/10";
      case "critical":
        return "bg-red-500/10";
      default:
        return "bg-primary/10";
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Access Denied
          </h1>
          <p className="text-muted-foreground mb-6">
            You do not have permission to access this page.
          </p>
          <Button onClick={() => navigate("/")} className="btn-primary">
            Return to Chat
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card backdrop-blur-md bg-opacity-80 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Chat
              </Button>
              <div className="border-l border-border pl-3">
                <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  Admin Dashboard
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {metrics.map((metric, idx) => (
            <Card
              key={idx}
              className={`p-6 border transition-all duration-300 hover:border-primary ${getStatusBgColor(
                metric.status
              )}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg bg-card ${getStatusColor(metric.status)}`}>
                  {metric.icon}
                </div>
                <span className={`text-xs font-semibold ${getStatusColor(metric.status)}`}>
                  {metric.status.toUpperCase()}
                </span>
              </div>
              <h3 className="text-sm text-muted-foreground mb-1">{metric.label}</h3>
              <p className="text-3xl font-bold text-foreground mb-2">{metric.value}</p>
              {metric.change && (
                <p className="text-xs text-muted-foreground">{metric.change}</p>
              )}
            </Card>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Query Volume */}
          <Card className="p-6">
            <h2 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Query Volume (7 Days)
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={queryVolumeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis stroke="#666666" />
                <YAxis stroke="#666666" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#050505",
                    border: "1px solid #1a1a1a",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="queries"
                  stroke="#FF4F00"
                  strokeWidth={2}
                  dot={{ fill: "#FF4F00", r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Module Usage */}
          <Card className="p-6">
            <h2 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              Module Usage Distribution
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={moduleUsageData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name} ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {moduleUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#050505",
                    border: "1px solid #1a1a1a",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Confidence Scores */}
        <Card className="p-6">
          <h2 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            Confidence Score Distribution
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={confidenceScoreData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
              <XAxis stroke="#666666" />
              <YAxis stroke="#666666" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#050505",
                  border: "1px solid #1a1a1a",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="count" fill="#FF4F00" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* System Status */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-green-500/10 border-green-500/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">API Health</h3>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
            <p className="text-2xl font-bold text-foreground">Operational</p>
            <p className="text-xs text-muted-foreground mt-2">
              All systems running normally
            </p>
          </Card>

          <Card className="p-6 bg-blue-500/10 border-blue-500/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">
                Database Load
              </h3>
              <Activity className="h-5 w-5 text-blue-500" />
            </div>
            <p className="text-2xl font-bold text-foreground">42%</p>
            <p className="text-xs text-muted-foreground mt-2">
              Healthy resource utilization
            </p>
          </Card>

          <Card className="p-6 bg-purple-500/10 border-purple-500/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">
                Memory Usage
              </h3>
              <Zap className="h-5 w-5 text-purple-500" />
            </div>
            <p className="text-2xl font-bold text-foreground">58%</p>
            <p className="text-xs text-muted-foreground mt-2">
              Optimal performance level
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
