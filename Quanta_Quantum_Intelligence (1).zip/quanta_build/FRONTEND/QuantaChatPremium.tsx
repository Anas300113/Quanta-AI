import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Loader2,
  Send,
  History,
  AlertCircle,
  BarChart3,
  Menu,
  X,
  Zap,
  Brain,
  TrendingUp,
} from "lucide-react";
import { Streamdown } from "streamdown";
import { ExampleQueries } from "@/components/ExampleQueries";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  metadata?: {
    confidence?: number;
    modules?: string[];
    regime?: any;
  };
}

export default function QuantaChatPremium() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const processQueryMutation = trpc.quanta.processQuery.useMutation();
  const historyQuery = trpc.quanta.getHistory.useQuery({ limit: 20 });
  const usageQuery = trpc.quanta.getUsage.useQuery();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const result = await processQueryMutation.mutateAsync({
        query: input,
        mode: "fast",
      });

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: result.final_answer,
        timestamp: new Date(),
        metadata: {
          confidence: result.overall_confidence,
          modules: result.full_trace.map((t) => `Cycle ${t.cycle}: ${t.decision}`),
          regime: result.market_regime,
        },
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: `Error: ${error instanceof Error ? error.message : "Failed to process query"}`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectQuery = (query: string) => {
    setInput(query);
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <div
        className={`${
          showSidebar ? "w-64" : "w-0"
        } border-r border-border bg-card transition-all duration-300 overflow-hidden flex flex-col`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-bold text-foreground">History</h2>
          <p className="text-xs text-muted-foreground mt-1">Recent queries</p>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {historyQuery.isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
            </div>
          ) : historyQuery.data && historyQuery.data.length > 0 ? (
            historyQuery.data.map((query) => (
              <button
                key={query.id}
                onClick={() => {
                  handleSelectQuery(query.query);
                  setShowSidebar(false);
                }}
                className="w-full text-left p-3 rounded-lg bg-secondary hover:bg-border transition-colors duration-200 group"
              >
                <p className="text-sm font-medium text-foreground line-clamp-2 group-hover:text-primary">
                  {query.query}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(query.createdAt).toLocaleDateString()}
                </p>
              </button>
            ))
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">
              No history yet
            </p>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-border bg-card backdrop-blur-md bg-opacity-80 sticky top-0 z-10">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowSidebar(!showSidebar)}
                className="p-2 hover:bg-secondary rounded-lg transition-colors duration-200 lg:hidden"
              >
                {showSidebar ? (
                  <X className="h-5 w-5 text-foreground" />
                ) : (
                  <Menu className="h-5 w-5 text-foreground" />
                )}
              </button>
              <div>
                <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  Quanta AI
                </h1>
                <p className="text-xs text-muted-foreground">
                  Multi-intelligence reasoning system
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {usageQuery.data && (
                <div className="text-sm text-right hidden sm:block">
                  <p className="text-muted-foreground">
                    <span className="text-foreground font-semibold">
                      {usageQuery.data.queryCount}
                    </span>
                    /{usageQuery.data.monthlyQuota} queries
                  </p>
                </div>
              )}

              {user?.role === "admin" && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/admin")}
                  className="gap-2"
                >
                  <BarChart3 className="h-4 w-4" />
                  <span className="hidden sm:inline">Admin</span>
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-center justify-center h-full">
              <div className="w-full max-w-3xl px-4">
                <div className="text-center mb-12 animate-fadeIn">
                  <div className="flex justify-center mb-6">
                    <div className="p-4 bg-primary/10 rounded-2xl">
                      <Zap className="h-12 w-12 text-primary" />
                    </div>
                  </div>
                  <h2 className="text-4xl font-bold text-foreground mb-3">
                    Welcome to Quanta AI
                  </h2>
                  <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                    Ask complex questions and receive intelligent, multi-faceted responses
                    powered by our autonomous reasoning system.
                  </p>
                </div>
                <ExampleQueries
                  onSelectQuery={handleSelectQuery}
                  isLoading={isLoading}
                />
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              } animate-slideUp`}
            >
              <div
                className={`max-w-2xl rounded-2xl p-4 sm:p-6 transition-all duration-300 ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-none"
                    : "bg-card border border-border text-foreground rounded-bl-none"
                }`}
              >
                {message.role === "assistant" && message.metadata ? (
                  <div className="space-y-4">
                    <div className="prose prose-invert max-w-none">
                      <Streamdown>{message.content}</Streamdown>
                    </div>

                    {/* Quality Metrics */}
                    {message.metadata.confidence !== undefined && (
                      <div className="border-t border-border pt-4 mt-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-foreground">
                            Confidence Score
                          </span>
                          <span className="text-sm font-bold text-primary">
                            {(message.metadata.confidence * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-gradient-to-r from-primary to-primary/60 h-2 rounded-full transition-all duration-500"
                            style={{
                              width: `${message.metadata.confidence * 100}%`,
                            }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Execution Trace */}
                    {message.metadata.modules && message.metadata.modules.length > 0 && (
                      <details className="border-t border-border pt-4 mt-4 group">
                        <summary className="text-sm font-semibold text-foreground cursor-pointer hover:text-primary transition-colors duration-200 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          Execution Trace ({message.metadata.modules.length} cycles)
                        </summary>
                        <div className="mt-3 space-y-2 text-sm">
                          {message.metadata.modules.map((mod, idx) => (
                            <div
                              key={idx}
                              className="text-muted-foreground flex items-start gap-2 animate-slideUp"
                            >
                              <span className="text-primary font-bold mt-0.5">•</span>
                              <span>{mod}</span>
                            </div>
                          ))}
                        </div>
                      </details>
                    )}

                    {/* Market Regime */}
                    {message.metadata.regime && (
                      <details className="border-t border-border pt-4 mt-4 group">
                        <summary className="text-sm font-semibold text-foreground cursor-pointer hover:text-primary transition-colors duration-200 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          Market Regime
                        </summary>
                        <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                          {[
                            {
                              label: "Volatility",
                              value: message.metadata.regime.volatility_regime,
                            },
                            {
                              label: "Liquidity",
                              value: message.metadata.regime.liquidity_regime,
                            },
                            {
                              label: "Macro",
                              value: message.metadata.regime.macro_regime,
                            },
                            {
                              label: "Correlation",
                              value: message.metadata.regime.correlation_regime,
                            },
                          ].map((item, idx) => (
                            <div key={idx} className="bg-secondary rounded-lg p-3">
                              <p className="text-muted-foreground text-xs font-medium">
                                {item.label}
                              </p>
                              <p className="text-foreground font-semibold mt-1">
                                {item.value}
                              </p>
                            </div>
                          ))}
                        </div>
                      </details>
                    )}
                  </div>
                ) : message.content.startsWith("Error:") ? (
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    <p>{message.content}</p>
                  </div>
                ) : (
                  <p className="text-base leading-relaxed">{message.content}</p>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start animate-slideUp">
              <div className="bg-card border border-border rounded-2xl rounded-bl-none p-4 flex items-center gap-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-100" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-200" />
                </div>
                <span className="text-sm text-muted-foreground">
                  Quanta is thinking...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-border bg-card backdrop-blur-md bg-opacity-80 sticky bottom-0 p-4 sm:p-6">
          <form onSubmit={handleSubmit} className="flex gap-3 max-w-4xl mx-auto">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Quanta AI anything..."
              disabled={isLoading}
              className="input-base flex-1"
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="btn-primary gap-2 px-6"
            >
              <Send className="h-4 w-4" />
              <span className="hidden sm:inline">Send</span>
            </Button>
          </form>
          <p className="text-xs text-muted-foreground text-center mt-3">
            Quanta can make mistakes. Consider checking important information.
          </p>
        </div>
      </div>
    </div>
  );
}
