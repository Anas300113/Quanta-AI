import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Users,
  Settings,
  AlertTriangle,
  TrendingUp,
  Server,
  Lock,
  BarChart3,
  Zap,
  Shield,
  ArrowLeft,
  Search,
  MoreVertical,
  Ban,
  CheckCircle,
  Clock,
} from "lucide-react";
import { Input } from "@/components/ui/input";

interface User {
  id: string;
  email: string;
  name: string;
  subscription: "free" | "pro" | "enterprise";
  status: "active" | "suspended" | "banned";
  queriesThisMonth: number;
  joinedDate: string;
}

interface FlaggedContent {
  id: string;
  userId: string;
  content: string;
  reason: string;
  timestamp: string;
  status: "pending" | "reviewed" | "approved" | "blocked";
}

export default function FounderControlPanel() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("users");
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data
  const users: User[] = [
    {
      id: "1",
      email: "john@example.com",
      name: "John Doe",
      subscription: "pro",
      status: "active",
      queriesThisMonth: 450,
      joinedDate: "2025-01-15",
    },
    {
      id: "2",
      email: "jane@example.com",
      name: "Jane Smith",
      subscription: "enterprise",
      status: "active",
      queriesThisMonth: 2400,
      joinedDate: "2024-11-20",
    },
    {
      id: "3",
      email: "bob@example.com",
      name: "Bob Johnson",
      subscription: "free",
      status: "suspended",
      queriesThisMonth: 0,
      joinedDate: "2026-02-01",
    },
  ];

  const flaggedContent: FlaggedContent[] = [
    {
      id: "1",
      userId: "4",
      content: "Request for harmful content generation",
      reason: "Potential misuse",
      timestamp: "2026-03-14T10:30:00Z",
      status: "pending",
    },
    {
      id: "2",
      userId: "5",
      content: "Attempted prompt injection attack",
      reason: "Security threat",
      timestamp: "2026-03-14T09:15:00Z",
      status: "reviewed",
    },
  ];

  const modelMetrics = {
    tokensUsedToday: "2.4M",
    avgResponseTime: "1.2s",
    errorRate: "0.02%",
    gpuUtilization: "68%",
    requestsPerMinute: 1240,
    activeUsers: 342,
  };

  const systemHealth = [
    { name: "API Uptime", status: "good", value: "99.98%" },
    { name: "Database", status: "good", value: "Healthy" },
    { name: "GPU Cluster", status: "good", value: "68% utilized" },
    { name: "Cache", status: "warning", value: "85% full" },
  ];

  const filteredUsers = users.filter(
    (u) =>
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Access Denied
          </h1>
          <p className="text-muted-foreground mb-6">
            Only founders and admins can access this panel.
          </p>
          <Button onClick={() => navigate("/")} className="btn-primary">
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card backdrop-blur-md bg-opacity-80 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <div className="border-l border-border pl-3">
                <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                  <Lock className="h-6 w-6 text-primary" />
                  Founder Control Panel
                </h1>
                <p className="text-xs text-muted-foreground">
                  Private infrastructure layer
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-border bg-card/50 sticky top-16 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8 overflow-x-auto">
            {[
              { id: "users", label: "User Management", icon: Users },
              { id: "monitoring", label: "Model Monitoring", icon: BarChart3 },
              { id: "moderation", label: "Moderation", icon: Shield },
              { id: "system", label: "Infrastructure", icon: Server },
              { id: "settings", label: "System Control", icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-4 border-b-2 transition-colors duration-200 flex items-center gap-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User Management */}
        {activeTab === "users" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">
                User Management
              </h2>
              <div className="flex gap-4 mb-6">
                <Input
                  placeholder="Search users by email or name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="input-base flex-1"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold">User</th>
                    <th className="text-left py-3 px-4 font-semibold">
                      Subscription
                    </th>
                    <th className="text-left py-3 px-4 font-semibold">Status</th>
                    <th className="text-left py-3 px-4 font-semibold">
                      Queries (Month)
                    </th>
                    <th className="text-left py-3 px-4 font-semibold">Joined</th>
                    <th className="text-left py-3 px-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="border-b border-border hover:bg-card/50">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-medium">{u.name}</p>
                          <p className="text-xs text-muted-foreground">{u.email}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-xs font-semibold capitalize">
                          {u.subscription}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-xs font-semibold px-2 py-1 rounded-full ${
                            u.status === "active"
                              ? "bg-green-500/10 text-green-500"
                              : u.status === "suspended"
                              ? "bg-yellow-500/10 text-yellow-500"
                              : "bg-red-500/10 text-red-500"
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">{u.queriesThisMonth}</td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(u.joinedDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <button className="p-1 hover:bg-secondary rounded">
                          <MoreVertical className="h-4 w-4 text-muted-foreground" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Model Monitoring */}
        {activeTab === "monitoring" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">Model Monitoring</h2>

            <div className="grid md:grid-cols-3 gap-4">
              {[
                {
                  label: "Tokens Used Today",
                  value: modelMetrics.tokensUsedToday,
                  icon: Zap,
                },
                {
                  label: "Avg Response Time",
                  value: modelMetrics.avgResponseTime,
                  icon: Clock,
                },
                {
                  label: "Error Rate",
                  value: modelMetrics.errorRate,
                  icon: AlertTriangle,
                },
              ].map((metric, idx) => {
                const Icon = metric.icon;
                return (
                  <Card key={idx} className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm text-muted-foreground">{metric.label}</p>
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-3xl font-bold">{metric.value}</p>
                  </Card>
                );
              })}
            </div>

            <Card className="p-6">
              <h3 className="font-bold mb-4">Real-time Performance</h3>
              <div className="space-y-4">
                {[
                  { label: "GPU Utilization", value: 68 },
                  { label: "Requests/Min", value: 85 },
                  { label: "Cache Hit Rate", value: 92 },
                ].map((metric, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">{metric.label}</span>
                      <span className="text-sm font-bold text-primary">
                        {metric.value}%
                      </span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full"
                        style={{ width: `${metric.value}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* Moderation */}
        {activeTab === "moderation" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">Content Moderation</h2>

            <div className="space-y-4">
              {flaggedContent.map((item) => (
                <Card key={item.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="font-semibold">{item.content}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        User ID: {item.userId} • {new Date(item.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <span
                      className={`text-xs font-semibold px-3 py-1 rounded-full ${
                        item.status === "pending"
                          ? "bg-yellow-500/10 text-yellow-500"
                          : item.status === "approved"
                          ? "bg-green-500/10 text-green-500"
                          : "bg-red-500/10 text-red-500"
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>
                  <p className="text-sm mb-4">
                    <strong>Reason:</strong> {item.reason}
                  </p>
                  {item.status === "pending" && (
                    <div className="flex gap-2">
                      <Button size="sm" className="btn-secondary">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                      <Button size="sm" className="btn-secondary">
                        <Ban className="h-4 w-4 mr-2" />
                        Block
                      </Button>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Infrastructure */}
        {activeTab === "system" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">Infrastructure Status</h2>

            <div className="grid md:grid-cols-2 gap-6">
              {systemHealth.map((item, idx) => (
                <Card
                  key={idx}
                  className={`p-6 border ${
                    item.status === "good"
                      ? "border-green-500/20 bg-green-500/5"
                      : "border-yellow-500/20 bg-yellow-500/5"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{item.name}</p>
                      <p className="text-2xl font-bold mt-2">{item.value}</p>
                    </div>
                    <div
                      className={`p-3 rounded-lg ${
                        item.status === "good"
                          ? "bg-green-500/10 text-green-500"
                          : "bg-yellow-500/10 text-yellow-500"
                      }`}
                    >
                      {item.status === "good" ? (
                        <CheckCircle className="h-6 w-6" />
                      ) : (
                        <AlertTriangle className="h-6 w-6" />
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* System Control */}
        {activeTab === "settings" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">System Control</h2>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="font-bold mb-4">Model Parameters</h3>
                <div className="space-y-4">
                  {[
                    { label: "Temperature", value: "0.7" },
                    { label: "Max Tokens", value: "4000" },
                    { label: "Reasoning Depth", value: "5 cycles" },
                  ].map((param, idx) => (
                    <div key={idx}>
                      <label className="text-sm font-medium">{param.label}</label>
                      <Input
                        defaultValue={param.value}
                        className="input-base mt-1"
                      />
                    </div>
                  ))}
                  <Button className="btn-primary w-full mt-4">
                    Update Parameters
                  </Button>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-bold mb-4">Safety Controls</h3>
                <div className="space-y-4">
                  {[
                    { label: "Content Filter Level", value: "strict" },
                    { label: "Rate Limit (req/min)", value: "1000" },
                    { label: "Max Query Length", value: "5000 chars" },
                  ].map((control, idx) => (
                    <div key={idx}>
                      <label className="text-sm font-medium">{control.label}</label>
                      <Input
                        defaultValue={control.value}
                        className="input-base mt-1"
                      />
                    </div>
                  ))}
                  <Button className="btn-primary w-full mt-4">
                    Update Safety Settings
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
