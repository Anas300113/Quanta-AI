import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { AlertCircle, TrendingUp, Users, Zap } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Check if user is admin
  if (!user || user.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-destructive" />
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-4">
            You do not have permission to access the admin dashboard.
          </p>
          <Button onClick={() => navigate("/")} variant="default">
            Return to Chat
          </Button>
        </div>
      </div>
    );
  }

  // Mock data for dashboard
  const queryVolumeData = [
    { date: "Mon", queries: 120, avgConfidence: 0.82 },
    { date: "Tue", queries: 150, avgConfidence: 0.85 },
    { date: "Wed", queries: 180, avgConfidence: 0.88 },
    { date: "Thu", queries: 165, avgConfidence: 0.86 },
    { date: "Fri", queries: 200, avgConfidence: 0.87 },
    { date: "Sat", queries: 95, avgConfidence: 0.84 },
    { date: "Sun", queries: 110, avgConfidence: 0.83 },
  ];

  const moduleUsageData = [
    { name: "Linguistic", value: 280, color: "#3b82f6" },
    { name: "Logical-Mathematical", value: 320, color: "#8b5cf6" },
    { name: "Statistical", value: 290, color: "#ec4899" },
    { name: "External Tools", value: 310, color: "#f59e0b" },
  ];

  const confidenceDistribution = [
    { range: "0.0-0.2", count: 5 },
    { range: "0.2-0.4", count: 15 },
    { range: "0.4-0.6", count: 45 },
    { range: "0.6-0.8", count: 120 },
    { range: "0.8-1.0", count: 235 },
  ];

  const stats = [
    {
      label: "Total Queries",
      value: "1,020",
      icon: Zap,
      trend: "+12%",
      trendUp: true,
    },
    {
      label: "Active Users",
      value: "84",
      icon: Users,
      trend: "+8%",
      trendUp: true,
    },
    {
      label: "Avg Confidence",
      value: "0.85",
      icon: TrendingUp,
      trend: "+0.03",
      trendUp: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-1">System performance and user analytics</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/")}>
            Back to Chat
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <Card key={idx} className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-3xl font-bold mt-2">{stat.value}</p>
                    <p className={`text-sm mt-2 ${stat.trendUp ? "text-green-600" : "text-red-600"}`}>
                      {stat.trend} from last week
                    </p>
                  </div>
                  <Icon className="h-8 w-8 text-muted-foreground" />
                </div>
              </Card>
            );
          })}
        </div>

        {/* Query Volume Chart */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">Query Volume & Confidence Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={queryVolumeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" domain={[0, 1]} />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="queries"
                stroke="#3b82f6"
                name="Queries"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="avgConfidence"
                stroke="#10b981"
                name="Avg Confidence"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Module Usage & Confidence Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Module Usage Pie Chart */}
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Module Usage Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={moduleUsageData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {moduleUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Confidence Distribution */}
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Confidence Score Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={confidenceDistribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="range" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* System Health */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">System Health</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">API Response Time</span>
                  <span className="text-sm text-muted-foreground">142ms</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "85%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Database Load</span>
                  <span className="text-sm text-muted-foreground">42%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "42%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Memory Usage</span>
                  <span className="text-sm text-muted-foreground">58%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-orange-500 h-2 rounded-full" style={{ width: "58%" }} />
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded">
                <span className="text-sm font-medium">Autonomous Research Loop</span>
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                  Active
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded">
                <span className="text-sm font-medium">Memory Optimization</span>
                <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                  Running
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded">
                <span className="text-sm font-medium">Model Calibration</span>
                <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                  Scheduled
                </span>
              </div>
            </div>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">Recent System Events</h2>
          <div className="space-y-3">
            {[
              { time: "2 minutes ago", event: "User submitted complex market analysis query", status: "success" },
              { time: "5 minutes ago", event: "Autonomous research loop completed iteration 3", status: "success" },
              { time: "12 minutes ago", event: "Memory optimization cycle completed", status: "success" },
              { time: "18 minutes ago", event: "High-confidence response generated (0.92)", status: "success" },
              { time: "25 minutes ago", event: "Query quota reset for user", status: "info" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 pb-3 border-b last:border-0">
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    item.status === "success" ? "bg-green-500" : "bg-blue-500"
                  }`}
                />
                <div className="flex-1">
                  <p className="text-sm font-medium">{item.event}</p>
                  <p className="text-xs text-muted-foreground mt-1">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
