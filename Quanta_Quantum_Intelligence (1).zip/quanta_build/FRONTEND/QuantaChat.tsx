import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send, History, AlertCircle, BarChart3, ThumbsUp, ThumbsDown, Brain, Zap } from "lucide-react";
import { Streamdown } from "streamdown";
import { ExampleQueries } from "@/components/ExampleQueries";

interface AgentOutput {
  agent: string;
  reasoning: string;
  answer: string;
  confidence: number;
  model: string;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  metadata?: {
    confidence?: number;
    agreementScore?: number;
    agentOutputs?: AgentOutput[];
    trace?: string[];
    responseId?: number;
    modulesUsed?: string;
    problemType?: string;
  };
}

interface FeedbackState {
  [responseId: number]: {
    submitted: boolean;
    rating: boolean | null;
    showComment: boolean;
    comment: string;
  };
}

export default function QuantaChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [feedbackState, setFeedbackState] = useState<FeedbackState>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const processQueryMutation = trpc.quanta.processQuery.useMutation();
  const submitFeedbackMutation = trpc.quanta.submitFeedback.useMutation();
  const historyQuery = trpc.quanta.getHistory.useQuery({ limit: 20 });
  const usageQuery = trpc.quanta.getUsage.useQuery();
  const learningProfileQuery = trpc.quanta.getLearningProfile.useQuery();

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setMessages((prev) => [...prev, {
      id: `user-${Date.now()}`, role: "user", content: input, timestamp: new Date(),
    }]);
    const sentInput = input;
    setInput("");
    setIsLoading(true);

    try {
      const result = await processQueryMutation.mutateAsync({ query: sentInput, mode: "fast" });

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: result.final_answer,
        timestamp: new Date(),
        metadata: {
          confidence: result.overall_confidence,
          agreementScore: result.agreement_score,
          agentOutputs: result.agent_outputs,
          trace: result.full_trace.map((t) => t.integrated_thought),
          responseId: result.responseId,
          modulesUsed: result.modules_used,
          problemType: result.problem_type,
        },
      };

      setMessages((prev) => [...prev, assistantMessage]);

      if (result.responseId) {
        setFeedbackState((prev) => ({
          ...prev,
          [result.responseId]: { submitted: false, rating: null, showComment: false, comment: "" },
        }));
      }
    } catch (error) {
      setMessages((prev) => [...prev, {
        id: `error-${Date.now()}`, role: "assistant",
        content: `Error: ${error instanceof Error ? error.message : "Failed to process query"}`,
        timestamp: new Date(),
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedback = (responseId: number, rating: boolean) => {
    setFeedbackState((prev) => ({ ...prev, [responseId]: { ...prev[responseId], rating, showComment: true } }));
  };

  const handleFeedbackSubmit = async (responseId: number, modulesUsed: string, problemType: string) => {
    const state = feedbackState[responseId];
    if (!state || state.rating === null) return;
    await submitFeedbackMutation.mutateAsync({
      responseId, rating: state.rating, comment: state.comment || undefined, modulesUsed, problemType,
    });
    setFeedbackState((prev) => ({ ...prev, [responseId]: { ...prev[responseId], submitted: true, showComment: false } }));
    learningProfileQuery.refetch();
  };

  const profile = learningProfileQuery.data;

  const confidenceColor = (v: number) =>
    v >= 0.8 ? "bg-green-500" : v >= 0.6 ? "bg-amber-500" : "bg-red-400";

  return (
    <div className="flex h-screen bg-background">
      <div className="flex-1 flex flex-col min-w-0">

        {/* Header */}
        <div className="border-b bg-card p-4 shadow-sm shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Quanta
              </h1>
              <p className="text-xs text-muted-foreground">Quantum Intelligence System</p>
            </div>
            <div className="flex items-center gap-3">
              {profile && profile.totalRatings > 0 && (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground border rounded-md px-2 py-1">
                  <Brain className="h-3 w-3" />
                  {profile.totalRatings} ratings · {profile.preferredDepth}
                </div>
              )}
              {usageQuery.data && (
                <span className="text-xs text-muted-foreground">
                  {usageQuery.data.queryCount}/{usageQuery.data.monthlyQuota}
                </span>
              )}
              <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)} className="gap-2">
                <History className="h-4 w-4" /> History
              </Button>
              {user?.role === "admin" && (
                <Button variant="outline" size="sm" onClick={() => navigate("/admin")} className="gap-2">
                  <BarChart3 className="h-4 w-4" /> Admin
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-center justify-center h-full">
              <div className="w-full max-w-3xl px-4 text-center">
                <h2 className="text-3xl font-semibold mb-2">Quanta Intelligence</h2>
                <p className="text-muted-foreground mb-8">
                  5 independent reasoning agents — Deductive, Analogical, Probabilistic, Adversarial, Empirical — analyse every query simultaneously and collapse into a single high-confidence answer.
                </p>
                <ExampleQueries onSelectQuery={setInput} isLoading={isLoading} />
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-2xl rounded-lg p-4 ${
                message.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border text-foreground"
              }`}>
                {message.role === "assistant" && message.metadata ? (
                  <div className="space-y-3">
                    <Streamdown>{message.content}</Streamdown>

                    {/* Confidence + Agreement */}
                    {message.metadata.confidence !== undefined && (
                      <div className="border-t pt-3 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-medium">Confidence</span>
                          <span>{(message.metadata.confidence * 100).toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-1.5">
                          <div className={`${confidenceColor(message.metadata.confidence)} h-1.5 rounded-full transition-all`}
                            style={{ width: `${message.metadata.confidence * 100}%` }} />
                        </div>
                        {message.metadata.agreementScore !== undefined && (
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Agent agreement</span>
                            <span>{(message.metadata.agreementScore * 100).toFixed(0)}%</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Agent outputs */}
                    {message.metadata.agentOutputs && message.metadata.agentOutputs.length > 0 && (
                      <details className="border-t pt-3">
                        <summary className="text-xs font-medium cursor-pointer hover:text-primary">
                          Agent reasoning ({message.metadata.agentOutputs.length} agents)
                        </summary>
                        <div className="mt-2 space-y-2">
                          {message.metadata.agentOutputs.map((a) => (
                            <div key={a.agent} className="text-xs border rounded p-2 space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{a.agent}</span>
                                <div className="flex items-center gap-2 text-muted-foreground">
                                  <span>{a.model.includes("gpt") ? "GPT-4" : "Claude"}</span>
                                  <span>{(a.confidence * 100).toFixed(0)}%</span>
                                </div>
                              </div>
                              <p className="text-muted-foreground leading-relaxed line-clamp-3">{a.answer}</p>
                            </div>
                          ))}
                        </div>
                      </details>
                    )}

                    {/* Execution trace */}
                    {message.metadata.trace && message.metadata.trace.length > 0 && (
                      <details className="border-t pt-3">
                        <summary className="text-xs font-medium cursor-pointer hover:text-primary">
                          Execution trace
                        </summary>
                        <div className="mt-2 text-xs text-muted-foreground space-y-1">
                          {message.metadata.trace.map((t, i) => <div key={i}>• {t}</div>)}
                        </div>
                      </details>
                    )}

                    {/* Feedback */}
                    {message.metadata.responseId && (() => {
                      const rid = message.metadata.responseId!;
                      const fb = feedbackState[rid];
                      if (!fb) return null;

                      if (fb.submitted) return (
                        <div className="border-t pt-3 text-xs text-muted-foreground flex items-center gap-1.5">
                          <Brain className="h-3 w-3" /> Feedback saved — Quanta will adapt
                        </div>
                      );

                      return (
                        <div className="border-t pt-3 space-y-2">
                          {!fb.showComment ? (
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">Helpful?</span>
                              <button onClick={() => handleFeedback(rid, true)}
                                className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-green-600 transition-colors">
                                <ThumbsUp className="h-4 w-4" />
                              </button>
                              <button onClick={() => handleFeedback(rid, false)}
                                className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-red-500 transition-colors">
                                <ThumbsDown className="h-4 w-4" />
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                                {fb.rating ? <ThumbsUp className="h-3 w-3 text-green-600" /> : <ThumbsDown className="h-3 w-3 text-red-500" />}
                                <span>{fb.rating ? "Glad it helped." : "Sorry about that."}</span>
                              </div>
                              <Textarea
                                placeholder='Optional: "too long", "more detail", etc.'
                                value={fb.comment}
                                onChange={(e) => setFeedbackState((prev) => ({
                                  ...prev, [rid]: { ...prev[rid], comment: e.target.value }
                                }))}
                                className="text-xs min-h-[56px] resize-none"
                              />
                              <Button size="sm" variant="outline" className="text-xs h-7"
                                onClick={() => handleFeedbackSubmit(rid, message.metadata!.modulesUsed ?? "", message.metadata!.problemType ?? "")}
                                disabled={submitFeedbackMutation.isPending}>
                                {submitFeedbackMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Submit"}
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                ) : message.content.startsWith("Error:") ? (
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                    <p>{message.content}</p>
                  </div>
                ) : (
                  <p>{message.content}</p>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm text-muted-foreground">Agents deliberating...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t bg-card p-4 shrink-0">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input value={input} onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Quanta anything..." disabled={isLoading} className="flex-1" />
            <Button type="submit" disabled={isLoading || !input.trim()} className="gap-2">
              <Send className="h-4 w-4" /> Send
            </Button>
          </form>
        </div>
      </div>

      {/* History sidebar */}
      {showHistory && (
        <div className="w-72 border-l bg-card flex flex-col shrink-0">
          <div className="p-4 border-b font-semibold">History</div>

          {profile && profile.totalRatings > 0 && (
            <div className="p-4 border-b bg-muted/30 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-medium">
                <Brain className="h-3 w-3" /> Learned profile
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {profile.learnedStyleSummary ?? "Building your profile..."}
              </p>
              <div className="grid grid-cols-2 gap-1 text-xs text-muted-foreground">
                <span>Depth: {profile.preferredDepth}</span>
                <span>Satisfaction: {profile.totalRatings > 0 ? Math.round((profile.positiveRatings / profile.totalRatings) * 100) : 0}%</span>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {historyQuery.isLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-4 w-4 animate-spin" /></div>
            ) : historyQuery.data?.length ? (
              historyQuery.data.map((q) => (
                <Card key={q.id} className="p-2 cursor-pointer hover:bg-accent transition-colors"
                  onClick={() => { setInput(q.query); setShowHistory(false); }}>
                  <p className="text-sm font-medium line-clamp-2">{q.query}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(q.createdAt).toLocaleDateString()}</p>
                </Card>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No history yet</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
