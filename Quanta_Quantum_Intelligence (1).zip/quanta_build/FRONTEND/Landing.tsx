import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  Brain,
  Zap,
  TrendingUp,
  Code2,
  BookOpen,
  Lightbulb,
  CheckCircle,
  Play,
  Github,
  Twitter,
  Mail,
} from "lucide-react";

export default function Landing() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("reasoning");

  const capabilities = [
    {
      id: "reasoning",
      name: "Advanced Reasoning",
      description: "Multi-step logical analysis with confidence scoring",
      icon: <Brain className="h-8 w-8" />,
      examples: ["Complex problem solving", "Strategic planning", "Risk analysis"],
    },
    {
      id: "research",
      name: "Research & Analysis",
      description: "Deep information synthesis and pattern recognition",
      icon: <BookOpen className="h-8 w-8" />,
      examples: ["Market research", "Data synthesis", "Trend analysis"],
    },
    {
      id: "coding",
      name: "Code Generation",
      description: "Write, debug, and optimize code across languages",
      icon: <Code2 className="h-8 w-8" />,
      examples: ["Full-stack development", "Algorithm design", "Code review"],
    },
    {
      id: "planning",
      name: "Strategic Planning",
      description: "Break down complex projects into actionable steps",
      icon: <TrendingUp className="h-8 w-8" />,
      examples: ["Project planning", "Resource allocation", "Timeline creation"],
    },
    {
      id: "innovation",
      name: "Innovation & Ideas",
      description: "Generate novel solutions and creative approaches",
      icon: <Lightbulb className="h-8 w-8" />,
      examples: ["Product ideation", "Business strategy", "Creative writing"],
    },
  ];

  const useCases = [
    {
      segment: "Students",
      problem: "Struggling with complex assignments and research papers",
      solution: "Get AI-powered explanations, research synthesis, and structured learning",
      icon: "🎓",
    },
    {
      segment: "Developers",
      problem: "Spending hours debugging and writing boilerplate code",
      solution: "Generate, review, and optimize code with AI assistance",
      icon: "💻",
    },
    {
      segment: "Businesses",
      problem: "Making data-driven decisions without deep analysis",
      solution: "Analyze markets, forecast trends, and strategize with AI insights",
      icon: "📊",
    },
    {
      segment: "Researchers",
      problem: "Synthesizing vast amounts of information manually",
      solution: "Accelerate research with AI-powered analysis and pattern discovery",
      icon: "🔬",
    },
  ];

  const trustMetrics = [
    { label: "Tasks Solved", value: "2.8M+", change: "+45% this quarter" },
    { label: "Users Served", value: "342K+", change: "Active daily users" },
    { label: "Accuracy Rate", value: "94.2%", change: "Verified by independent audit" },
    { label: "Uptime", value: "99.98%", change: "Enterprise-grade reliability" },
  ];

  const pricingPlans = [
    {
      name: "Free",
      price: "Free",
      description: "Perfect for exploring",
      features: [
        "50 queries/month",
        "Basic reasoning modules",
        "Community support",
        "Standard response time",
      ],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Pro",
      price: "$29",
      period: "/month",
      description: "For serious users",
      features: [
        "Unlimited queries",
        "All reasoning modules",
        "Priority support",
        "Faster response time",
        "Export responses",
        "API access",
      ],
      cta: "Start Free Trial",
      highlighted: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For organizations",
      features: [
        "Custom deployment",
        "Dedicated support",
        "Advanced analytics",
        "Team collaboration",
        "SLA guarantee",
        "Custom integrations",
      ],
      cta: "Contact Sales",
      highlighted: false,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Quanta AI</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#capabilities" className="text-sm hover:text-primary transition">
              Capabilities
            </a>
            <a href="#how-it-works" className="text-sm hover:text-primary transition">
              How It Works
            </a>
            <a href="#use-cases" className="text-sm hover:text-primary transition">
              Use Cases
            </a>
            <a href="#pricing" className="text-sm hover:text-primary transition">
              Pricing
            </a>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/admin")}
              className="hidden sm:inline"
            >
              Sign In
            </Button>
            <Button
              size="sm"
              className="btn-primary"
              onClick={() => navigate("/app")}
            >
              Try Now
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 sm:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto animate-slideUp">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              An AI That Can{" "}
              <span className="text-primary">Reason, Research & Execute</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-8">
              Quanta AI combines multi-intelligence reasoning with transparent execution traces.
              See exactly how the AI thinks, and trust the results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="btn-primary gap-2"
              onClick={() => navigate("/app")}
            >
              Try for Free <ArrowRight className="h-4 w-4" />
            </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
              >
                <Play className="h-4 w-4" /> Watch Demo
              </Button>
              <Button
                size="lg"
                variant="ghost"
                className="gap-2"
              >
                View Capabilities <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* AI Capability Showcase */}
      <section id="capabilities" className="py-20 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">What Quanta Can Do</h2>
            <p className="text-lg text-muted-foreground">
              Multi-intelligence system that adapts to your problem
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Capability Tabs */}
            <div className="space-y-4">
              {capabilities.map((cap) => (
                <button
                  key={cap.id}
                  onClick={() => setActiveTab(cap.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all duration-300 ${
                    activeTab === cap.id
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`${
                        activeTab === cap.id ? "text-primary" : "text-muted-foreground"
                      }`}
                    >
                      {cap.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{cap.name}</h3>
                      <p className="text-sm text-muted-foreground">{cap.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Capability Details */}
            <div className="bg-card border border-border rounded-xl p-8 animate-slideUp">
              {capabilities.map((cap) => (
                activeTab === cap.id && (
                  <div key={cap.id} className="space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold mb-2">{cap.name}</h3>
                      <p className="text-muted-foreground">{cap.description}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-3">Example Use Cases</h4>
                      <ul className="space-y-2">
                        {cap.examples.map((example, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                            <span className="text-sm">{example}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="bg-secondary rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        <strong>Example Prompt:</strong> "Analyze the risks in this portfolio and suggest mitigation strategies"
                      </p>
                    </div>
                  </div>
                )
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 border-t border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">How Quanta Works</h2>
            <p className="text-lg text-muted-foreground">
              Transparent reasoning pipeline from input to output
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4 items-center">
            {[
              { step: "1", label: "Your Prompt", icon: "📝" },
              { step: "→", label: "", icon: "" },
              { step: "2", label: "AI Reasoning", icon: "🧠" },
              { step: "→", label: "", icon: "" },
              { step: "3", label: "Tool Usage", icon: "🔧" },
              { step: "→", label: "", icon: "" },
              { step: "4", label: "Knowledge Retrieval", icon: "📚" },
              { step: "→", label: "", icon: "" },
              { step: "5", label: "Output", icon: "✨" },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                {item.step === "→" ? (
                  <div className="text-2xl text-primary">→</div>
                ) : (
                  <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                    <div className="text-3xl mb-2">{item.icon}</div>
                    <div className="text-xs font-semibold text-primary">{item.step}</div>
                    <div className="text-sm font-medium mt-1">{item.label}</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section id="use-cases" className="py-20 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Built for Everyone</h2>
            <p className="text-lg text-muted-foreground">
              From students to enterprises, Quanta adapts to your needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((useCase, idx) => (
              <div
                key={idx}
                className="bg-card border border-border rounded-xl p-6 hover:border-primary transition-all duration-300"
              >
                <div className="text-4xl mb-4">{useCase.icon}</div>
                <h3 className="text-lg font-bold mb-2">{useCase.segment}</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold mb-1">
                      Problem
                    </p>
                    <p className="text-sm">{useCase.problem}</p>
                  </div>
                  <div>
                    <p className="text-xs text-primary font-semibold mb-1">Solution</p>
                    <p className="text-sm">{useCase.solution}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust & Credibility */}
      <section className="py-20 border-t border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Trusted by Thousands</h2>
            <p className="text-lg text-muted-foreground">
              Enterprise-grade reliability and transparency
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {trustMetrics.map((metric, idx) => (
              <div key={idx} className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {metric.value}
                </div>
                <div className="font-semibold mb-1">{metric.label}</div>
                <div className="text-sm text-muted-foreground">{metric.change}</div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="font-bold mb-2">Safety First</h4>
              <p className="text-sm text-muted-foreground">
                Content filtering, bias detection, and responsible AI practices
              </p>
            </div>
            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="font-bold mb-2">Transparent</h4>
              <p className="text-sm text-muted-foreground">
                See reasoning traces, confidence scores, and decision logic
              </p>
            </div>
            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="font-bold mb-2">Reliable</h4>
              <p className="text-sm text-muted-foreground">
                99.98% uptime, enterprise SLA, and dedicated support
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-lg text-muted-foreground">
              Choose the plan that fits your needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, idx) => (
              <div
                key={idx}
                className={`rounded-xl border transition-all duration-300 ${
                  plan.highlighted
                    ? "border-primary bg-primary/5 scale-105"
                    : "border-border bg-card hover:border-primary/50"
                }`}
              >
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-muted-foreground text-sm mb-6">{plan.description}</p>

                  <div className="mb-6">
                    <div className="text-4xl font-bold">
                      {plan.price}
                      {plan.period && (
                        <span className="text-lg text-muted-foreground font-normal">
                          {plan.period}
                        </span>
                      )}
                    </div>
                  </div>

                  <Button
                    className={`w-full mb-8 ${
                      plan.highlighted ? "btn-primary" : "btn-secondary"
                    }`}
                  >
                    {plan.cta}
                  </Button>

                  <ul className="space-y-3">
                    {plan.features.map((feature, fidx) => (
                      <li key={fidx} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 border-t border-border bg-card/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Experience Quanta?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of users who are already using Quanta AI to solve complex problems.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="btn-primary gap-2" onClick={() => navigate("/")}>
              Try for Free <ArrowRight className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="gap-2">
              <Mail className="h-4 w-4" /> Contact Sales
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Features</a></li>
                <li><a href="#" className="hover:text-primary">Pricing</a></li>
                <li><a href="#" className="hover:text-primary">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">About</a></li>
                <li><a href="#" className="hover:text-primary">Blog</a></li>
                <li><a href="#" className="hover:text-primary">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Privacy</a></li>
                <li><a href="#" className="hover:text-primary">Terms</a></li>
                <li><a href="#" className="hover:text-primary">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <div className="flex gap-4">
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Quanta AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
