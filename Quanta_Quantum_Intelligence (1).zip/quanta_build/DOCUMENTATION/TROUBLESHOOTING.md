# Quanta AI Platform - Troubleshooting Guide

Solutions to common issues and problems.

## Installation & Setup Issues

### Issue: Node.js not found

**Error**: `command not found: node`

**Solution**:
1. Download Node.js 18+ from https://nodejs.org/
2. Install it following the official guide
3. Verify installation: `node --version`

---

### Issue: npm install fails

**Error**: `npm ERR! code ERESOLVE`

**Solution**:
```bash
# Clear npm cache
npm cache clean --force

# Try installing again
npm install

# If still fails, use legacy peer deps
npm install --legacy-peer-deps
```

---

### Issue: pnpm not found

**Error**: `command not found: pnpm`

**Solution**:
```bash
# Install pnpm globally
npm install -g pnpm

# Verify
pnpm --version
```

---

## Database Issues

### Issue: Cannot connect to database

**Error**: `Error: connect ECONNREFUSED 127.0.0.1:3306`

**Solution**:
1. Verify MySQL is running:
   ```bash
   mysql -u root -p
   ```
2. Check DATABASE_URL in .env:
   ```
   DATABASE_URL=mysql://root:password@localhost:3306/quanta_ai
   ```
3. Ensure database exists:
   ```sql
   CREATE DATABASE quanta_ai;
   ```

---

### Issue: Permission denied for database user

**Error**: `Access denied for user 'root'@'localhost'`

**Solution**:
1. Create a dedicated database user:
   ```sql
   CREATE USER 'quanta'@'localhost' IDENTIFIED BY 'secure_password';
   GRANT ALL PRIVILEGES ON quanta_ai.* TO 'quanta'@'localhost';
   FLUSH PRIVILEGES;
   ```
2. Update .env:
   ```
   DATABASE_URL=mysql://quanta:secure_password@localhost:3306/quanta_ai
   ```

---

### Issue: Schema migration failed

**Error**: `Error: Migration failed`

**Solution**:
```bash
# Check migration status
npm run db:status

# Reset migrations (WARNING: deletes data)
npm run db:reset

# Re-run migrations
npm run db:push
```

---

## Backend Issues

### Issue: Port 3000 already in use

**Error**: `Error: listen EADDRINUSE :::3000`

**Solution**:
```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or use a different port
PORT=3001 npm run dev
```

---

### Issue: Backend tests failing

**Error**: `Tests failed: 5 failed, 5 passed`

**Solution**:
```bash
# Run tests with verbose output
npm test -- --reporter=verbose

# Run specific test file
npm test server/quanta.test.ts

# Check for database connection
npm test -- --reporter=verbose 2>&1 | grep -i "database\|connection"
```

---

### Issue: tRPC procedure not found

**Error**: `Error: No procedure found at path 'quanta.processQuery'`

**Solution**:
1. Verify procedure is exported in `server/routers.ts`
2. Check procedure name spelling
3. Restart backend server: `npm run dev`
4. Clear browser cache: Ctrl+Shift+Delete

---

## Frontend Issues

### Issue: Frontend not loading

**Error**: Blank page or 404

**Solution**:
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear Vite cache
rm -rf .vite

# Restart dev server
npm run dev
```

---

### Issue: Styling not applied

**Error**: Components appear unstyled

**Solution**:
1. Verify Tailwind CSS is imported in `index.css`
2. Check `tailwind.config.js` exists
3. Rebuild CSS:
   ```bash
   npm run build
   ```
4. Clear browser cache and hard refresh (Ctrl+Shift+R)

---

### Issue: API calls returning 404

**Error**: `POST /api/trpc/quanta.processQuery 404`

**Solution**:
1. Verify backend is running on port 5000
2. Check VITE_API_URL in .env
3. Verify procedure name in `server/routers.ts`
4. Check browser console for exact error

---

### Issue: Authentication not working

**Error**: `401 Unauthorized` on protected routes

**Solution**:
1. Verify JWT_SECRET is set in .env
2. Check token is being sent in Authorization header
3. Verify user exists in database
4. Check token expiration:
   ```bash
   # Decode JWT (use jwt.io)
   ```

---

## Performance Issues

### Issue: Slow query processing

**Error**: Queries taking >10 seconds

**Solution**:
1. Check server logs for bottlenecks
2. Verify database indexes are created:
   ```sql
   SHOW INDEXES FROM queries;
   ```
3. Check GPU utilization:
   ```bash
   nvidia-smi
   ```
4. Reduce reasoning depth in settings

---

### Issue: High memory usage

**Error**: Process using >2GB RAM

**Solution**:
1. Check for memory leaks in logs
2. Reduce cache size in configuration
3. Restart backend service
4. Monitor with:
   ```bash
   top -p $(pgrep -f "node.*server")
   ```

---

### Issue: Database queries slow

**Error**: Database operations taking >1s

**Solution**:
1. Add missing indexes:
   ```sql
   CREATE INDEX idx_userId ON queries(userId);
   CREATE INDEX idx_createdAt ON queries(createdAt);
   ```
2. Analyze query performance:
   ```sql
   EXPLAIN SELECT * FROM queries WHERE userId = 1;
   ```
3. Archive old data to separate table

---

## Deployment Issues

### Issue: Build fails in production

**Error**: `npm run build` fails

**Solution**:
```bash
# Check for TypeScript errors
npm run check

# Build with verbose output
npm run build -- --debug

# Fix common issues
npm run format
npm install
npm run build
```

---

### Issue: Environment variables not loaded

**Error**: `undefined` values for env variables

**Solution**:
1. Verify .env file exists in root directory
2. Restart dev server after changing .env
3. Use correct variable names (VITE_ prefix for frontend)
4. Check .env is not in .gitignore

---

## Debugging Tips

### Enable Debug Logging

```bash
# Backend
DEBUG=* npm run dev

# Frontend
VITE_DEBUG=true npm run dev
```

### Check Logs

```bash
# Backend logs
tail -f logs/backend.log

# Frontend console
# Open DevTools: F12 or Cmd+Option+I
```

### Database Debugging

```bash
# Connect to database
mysql -u root -p quanta_ai

# Check tables
SHOW TABLES;

# Check data
SELECT * FROM queries LIMIT 5;

# Check indexes
SHOW INDEXES FROM queries;
```

### Network Debugging

```bash
# Check API responses
curl -H "Authorization: Bearer TOKEN" \
  http://localhost:3000/api/trpc/quanta.processQuery

# Monitor network requests
# Open DevTools > Network tab
```

---

## Getting Help

1. **Check this guide first** - Most issues are covered here
2. **Review error messages** - They often contain the solution
3. **Check logs** - Backend and frontend logs provide clues
4. **Search documentation** - API_REFERENCE.md has detailed info
5. **Contact support** - support@quanta.ai

---

## Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| `ECONNREFUSED` | Database not running | Start MySQL service |
| `EADDRINUSE` | Port already in use | Kill process or use different port |
| `ENOMEM` | Out of memory | Increase RAM or restart service |
| `ENOTFOUND` | DNS resolution failed | Check network connection |
| `ETIMEDOUT` | Request timeout | Check server health, increase timeout |
| `EACCES` | Permission denied | Check file permissions |
| `ENOENT` | File not found | Verify file path exists |

---

## Performance Optimization

### Frontend Optimization
- Enable code splitting: `npm run build`
- Use React DevTools to find slow renders
- Optimize images and assets
- Enable compression in nginx/apache

### Backend Optimization
- Add database indexes
- Use connection pooling
- Enable query caching
- Monitor CPU and memory usage

### Database Optimization
- Regular VACUUM and ANALYZE
- Archive old data
- Use appropriate data types
- Monitor slow query log

---

## Security Checklist

- [ ] Change default passwords
- [ ] Update JWT_SECRET to strong value
- [ ] Enable HTTPS in production
- [ ] Set CORS properly
- [ ] Validate all user inputs
- [ ] Use environment variables for secrets
- [ ] Enable rate limiting
- [ ] Set up monitoring and alerts
- [ ] Regular security audits
- [ ] Keep dependencies updated

---

**Last Updated**: March 2026
**Version**: 1.0.0
