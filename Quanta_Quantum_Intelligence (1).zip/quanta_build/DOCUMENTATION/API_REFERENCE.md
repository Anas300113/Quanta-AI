# Quanta AI Platform - API Reference

Complete API documentation for the Quanta AI backend services.

## Base URL

```
http://localhost:3000/api/trpc
```

## Authentication

All protected endpoints require a valid JWT token in the Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

---

## Endpoints

### 1. Process Query

**Endpoint**: `POST /quanta.processQuery`

**Description**: Submit a query to the Quanta AI orchestrator for processing.

**Request Body**:
```json
{
  "query": "What are the risks in a diversified portfolio?",
  "mode": "standard",
  "context": {
    "domain": "finance",
    "userLevel": "intermediate"
  }
}
```

**Response**:
```json
{
  "id": "query_123",
  "content": "Based on multi-intelligence analysis...",
  "confidenceScore": 0.87,
  "confidenceBound": 0.92,
  "qualityScore": 0.89,
  "executionTraces": [
    {
      "cycle": 1,
      "module": "Linguistic",
      "decision": "Process",
      "qualityScore": 0.85
    }
  ],
  "processingTimeMs": 2341,
  "marketRegime": {
    "volatility": "elevated",
    "liquidity": "normal",
    "macroCondition": "uncertain"
  }
}
```

**Parameters**:
- `query` (string, required): The user's question or prompt
- `mode` (string, optional): Processing mode - "fast", "standard", or "deep" (default: "standard")
- `context` (object, optional): Additional context for reasoning

**Response Fields**:
- `id`: Unique query identifier
- `content`: The AI's response
- `confidenceScore`: Confidence in the response (0-1)
- `confidenceBound`: Upper bound of confidence interval
- `qualityScore`: Overall quality assessment (0-1)
- `executionTraces`: Array of reasoning cycles
- `processingTimeMs`: Total processing time in milliseconds
- `marketRegime`: Current market conditions (if applicable)

**Status Codes**:
- `200 OK`: Query processed successfully
- `400 Bad Request`: Invalid query format
- `401 Unauthorized`: Missing or invalid token
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Processing error

---

### 2. Get Query History

**Endpoint**: `GET /quanta.getQueryHistory`

**Description**: Retrieve the user's query history.

**Query Parameters**:
- `limit` (number, optional): Number of queries to return (default: 20, max: 100)
- `offset` (number, optional): Pagination offset (default: 0)
- `sortBy` (string, optional): Sort field - "date", "confidence", "quality" (default: "date")

**Response**:
```json
{
  "queries": [
    {
      "id": "query_123",
      "content": "What are the risks in a diversified portfolio?",
      "createdAt": "2026-03-14T10:30:00Z",
      "responseId": "response_456",
      "confidenceScore": 0.87,
      "qualityScore": 0.89
    }
  ],
  "total": 42,
  "limit": 20,
  "offset": 0
}
```

**Status Codes**:
- `200 OK`: History retrieved successfully
- `401 Unauthorized`: Missing or invalid token
- `500 Internal Server Error`: Database error

---

### 3. Get Query Details

**Endpoint**: `GET /quanta.getQueryDetails`

**Description**: Get detailed information about a specific query.

**Query Parameters**:
- `queryId` (string, required): The query ID

**Response**:
```json
{
  "query": {
    "id": "query_123",
    "content": "What are the risks in a diversified portfolio?",
    "mode": "standard",
    "createdAt": "2026-03-14T10:30:00Z"
  },
  "response": {
    "id": "response_456",
    "content": "Based on multi-intelligence analysis...",
    "confidenceScore": 0.87,
    "qualityScore": 0.89,
    "executionTraces": [
      {
        "cycle": 1,
        "module": "Linguistic",
        "decision": "Process",
        "qualityScore": 0.85,
        "reasoning": "Analyzed query structure..."
      }
    ]
  }
}
```

**Status Codes**:
- `200 OK`: Details retrieved successfully
- `404 Not Found`: Query not found
- `401 Unauthorized`: Access denied

---

### 4. Get System Metrics

**Endpoint**: `GET /quanta.getMetrics`

**Description**: Get system performance metrics (admin only).

**Query Parameters**:
- `timeRange` (string, optional): "hour", "day", "week", "month" (default: "day")

**Response**:
```json
{
  "timestamp": "2026-03-14T11:00:00Z",
  "metrics": {
    "totalQueries": 2847,
    "avgResponseTime": 1.23,
    "errorRate": 0.02,
    "activeUsers": 342,
    "gpuUtilization": 68,
    "requestsPerMinute": 1240
  },
  "moduleUsage": {
    "Linguistic": 450,
    "LogicalMathematical": 380,
    "Statistical": 320,
    "Spatial": 180,
    "Musical": 45
  },
  "confidenceDistribution": {
    "0-20": 5,
    "20-40": 12,
    "40-60": 45,
    "60-80": 180,
    "80-100": 608
  }
}
```

**Status Codes**:
- `200 OK`: Metrics retrieved successfully
- `401 Unauthorized`: Not an admin user
- `500 Internal Server Error`: Metrics collection error

---

### 5. Get User Profile

**Endpoint**: `GET /auth.me`

**Description**: Get current user's profile information.

**Response**:
```json
{
  "id": 1,
  "openId": "user_123",
  "name": "John Doe",
  "email": "john@example.com",
  "role": "user",
  "createdAt": "2026-01-15T10:00:00Z",
  "lastSignedIn": "2026-03-14T11:00:00Z"
}
```

**Status Codes**:
- `200 OK`: Profile retrieved successfully
- `401 Unauthorized`: Not authenticated

---

### 6. Logout

**Endpoint**: `POST /auth.logout`

**Description**: Logout the current user and clear session.

**Response**:
```json
{
  "success": true
}
```

**Status Codes**:
- `200 OK`: Logout successful
- `401 Unauthorized`: Not authenticated

---

## Error Responses

All error responses follow this format:

```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Detailed error message",
    "details": {
      "field": "query",
      "issue": "Query cannot be empty"
    }
  }
}
```

**Common Error Codes**:
- `INVALID_REQUEST`: Request validation failed
- `UNAUTHORIZED`: Authentication required
- `FORBIDDEN`: Insufficient permissions
- `NOT_FOUND`: Resource not found
- `RATE_LIMITED`: Too many requests
- `INTERNAL_ERROR`: Server error

---

## Rate Limiting

- **Default Limit**: 60 requests per minute per user
- **Pro Plan**: 500 requests per minute
- **Enterprise**: Custom limits

**Rate Limit Headers**:
```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1647270000
```

---

## Pagination

For endpoints that return lists, use these parameters:

- `limit`: Number of items per page (1-100, default: 20)
- `offset`: Number of items to skip (default: 0)

**Example**:
```
GET /quanta.getQueryHistory?limit=50&offset=100
```

---

## Webhooks (Future)

Webhooks will be available for:
- Query completion
- System alerts
- User actions
- Moderation events

---

## SDK Examples

### JavaScript/TypeScript

```typescript
import { trpc } from '@/lib/trpc';

// Process a query
const response = await trpc.quanta.processQuery.mutate({
  query: "What are the risks in a diversified portfolio?",
  mode: "standard"
});

// Get history
const history = await trpc.quanta.getQueryHistory.query({
  limit: 20,
  offset: 0
});
```

### Python

```python
import requests

url = "http://localhost:3000/api/trpc/quanta.processQuery"
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}
payload = {
    "query": "What are the risks in a diversified portfolio?",
    "mode": "standard"
}

response = requests.post(url, json=payload, headers=headers)
data = response.json()
```

### cURL

```bash
curl -X POST http://localhost:3000/api/trpc/quanta.processQuery \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What are the risks in a diversified portfolio?",
    "mode": "standard"
  }'
```

---

## Versioning

Current API Version: **v1.0.0**

Future versions will be available at:
- `/api/trpc/v2/...`
- `/api/trpc/v3/...`

Backward compatibility is maintained for 12 months after a new version release.

---

## Support

For API support:
1. Check this documentation
2. Review error messages and codes
3. Check system status page
4. Contact support@quanta.ai

**Last Updated**: March 2026
