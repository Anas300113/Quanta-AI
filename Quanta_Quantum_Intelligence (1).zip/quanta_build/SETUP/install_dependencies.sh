#!/bin/bash

# Quanta AI Platform - Dependency Installation Script
# This script installs all required dependencies for the platform

set -e

echo "🚀 Quanta AI Platform - Dependency Installation"
echo "=================================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm from https://nodejs.org/"
    exit 1
fi

echo "✅ npm version: $(npm --version)"

# Install pnpm globally if not present
if ! command -v pnpm &> /dev/null; then
    echo "📦 Installing pnpm..."
    npm install -g pnpm
fi

echo "✅ pnpm version: $(pnpm --version)"

# Check for MySQL/TiDB
if ! command -v mysql &> /dev/null; then
    echo "⚠️  MySQL client not found. You'll need MySQL/TiDB running."
    echo "   Install from: https://dev.mysql.com/downloads/mysql/"
fi

echo ""
echo "✅ All dependencies are installed!"
echo ""
echo "📝 Next steps:"
echo "   1. Copy SETUP/environment_template.env to .env"
echo "   2. Fill in your database credentials"
echo "   3. Run: cd BACKEND && npm install"
echo "   4. Run: cd ../FRONTEND && npm install"
echo ""
