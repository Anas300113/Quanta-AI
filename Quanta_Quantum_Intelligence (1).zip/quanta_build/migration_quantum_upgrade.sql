-- Quanta — Migration: Quantum Intelligence upgrade
-- Run against your existing quanta_ai database

USE quanta_ai;

-- Add new columns to responses table
ALTER TABLE responses
  ADD COLUMN IF NOT EXISTS agreementScore INT DEFAULT 0,
  ADD COLUMN IF NOT EXISTS modulesUsed VARCHAR(256),
  ADD COLUMN IF NOT EXISTS problemType VARCHAR(64);

-- ==========================================
-- FEEDBACK
-- ==========================================
CREATE TABLE IF NOT EXISTS feedback (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  userId      INT NOT NULL,
  responseId  INT NOT NULL,
  rating      BOOLEAN NOT NULL,
  comment     TEXT,
  modulesUsed VARCHAR(256),
  problemType VARCHAR(64),
  createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId)     REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (responseId) REFERENCES responses(id) ON DELETE CASCADE,
  INDEX idx_feedback_user   (userId),
  INDEX idx_feedback_rating (rating)
);

-- ==========================================
-- CONVERSATION MEMORY
-- ==========================================
CREATE TABLE IF NOT EXISTS conversationMemory (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  userId           INT NOT NULL,
  userMessage      TEXT NOT NULL,
  assistantMessage TEXT NOT NULL,
  qualityScore     FLOAT DEFAULT 0 NOT NULL,
  wasPositive      BOOLEAN,
  createdAt        TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_memory_user    (userId),
  INDEX idx_memory_created (userId, createdAt DESC)
);

-- ==========================================
-- USER LEARNING PROFILE
-- ==========================================
CREATE TABLE IF NOT EXISTS userLearningProfile (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  userId                INT NOT NULL UNIQUE,
  totalRatings          INT DEFAULT 0 NOT NULL,
  positiveRatings       INT DEFAULT 0 NOT NULL,
  preferredDepth        VARCHAR(32) DEFAULT 'standard',
  dominantProblemTypes  VARCHAR(256),
  bestPerformingModules VARCHAR(256),
  avgPositiveConfidence FLOAT DEFAULT 0,
  learnedStyleSummary   TEXT,
  createdAt             TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt             TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);
