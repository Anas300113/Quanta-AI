import { describe, it, expect, beforeEach, vi } from "vitest";
import { quantaOrchestrator } from "./quanta-orchestrator";

describe("Quanta Orchestrator", () => {
  describe("process_query", () => {
    it("should process a simple query and return a response", async () => {
      const query = "What is artificial intelligence?";
      const result = await quantaOrchestrator.process_query(query, "fast");

      expect(result).toBeDefined();
      expect(result.query).toBe(query);
      expect(result.final_answer).toBeDefined();
      expect(result.overall_confidence).toBeGreaterThanOrEqual(0);
      expect(result.overall_confidence).toBeLessThanOrEqual(1);
    });

    it("should include execution traces in the response", async () => {
      const result = await quantaOrchestrator.process_query("Test query", "fast");

      expect(result.full_trace).toBeDefined();
      expect(Array.isArray(result.full_trace)).toBe(true);
      expect(result.full_trace.length).toBeGreaterThan(0);

      const firstTrace = result.full_trace[0];
      expect(firstTrace.cycle).toBe(1);
      expect(firstTrace.decision).toBeDefined();
      expect(firstTrace.quality_score).toBeGreaterThanOrEqual(0);
      expect(firstTrace.quality_score).toBeLessThanOrEqual(1);
    });

    it("should include market regime information", async () => {
      const result = await quantaOrchestrator.process_query("Market analysis query", "fast");

      expect(result.market_regime).toBeDefined();
      expect(result.market_regime.volatility_regime).toBeDefined();
      expect(result.market_regime.liquidity_regime).toBeDefined();
      expect(result.market_regime.macro_regime).toBeDefined();
      expect(result.market_regime.correlation_regime).toBeDefined();
    });

    it("should classify queries correctly", async () => {
      // Risk analysis query
      const riskResult = await quantaOrchestrator.process_query(
        "Calculate the Value at Risk for this portfolio",
        "fast"
      );
      expect(riskResult.final_answer).toBeDefined();

      // Market commentary query
      const marketResult = await quantaOrchestrator.process_query(
        "What is the market impact of AI on labor?",
        "fast"
      );
      expect(marketResult.final_answer).toBeDefined();

      // General inquiry
      const generalResult = await quantaOrchestrator.process_query(
        "Tell me about quantum computing",
        "fast"
      );
      expect(generalResult.final_answer).toBeDefined();
    });

    it("should handle different processing modes", async () => {
      const fastResult = await quantaOrchestrator.process_query("Test", "fast");
      const standardResult = await quantaOrchestrator.process_query("Test", "standard");

      // Standard mode should have more cycles
      expect(standardResult.full_trace.length).toBeGreaterThanOrEqual(fastResult.full_trace.length);
    });

    it("should maintain confidence bounds", async () => {
      const result = await quantaOrchestrator.process_query("Complex analysis", "fast");

      for (const trace of result.full_trace) {
        expect(trace.quality_score).toBeGreaterThanOrEqual(0);
        expect(trace.quality_score).toBeLessThanOrEqual(1);
      }
    });
  });

  describe("module routing", () => {
    it("should activate appropriate modules for different query types", async () => {
      // This test verifies that the skill router is working
      const result = await quantaOrchestrator.process_query(
        "What is the risk in my portfolio?",
        "fast"
      );

      expect(result.full_trace).toBeDefined();
      expect(result.full_trace.length).toBeGreaterThan(0);
      // The integrated thought should mention analysis
      expect(result.final_answer.toLowerCase()).toContain("analysis");
    });
  });

  describe("response quality", () => {
    it("should provide structured responses", async () => {
      const result = await quantaOrchestrator.process_query("Test query", "fast");

      // Verify response structure
      expect(result).toHaveProperty("query");
      expect(result).toHaveProperty("final_answer");
      expect(result).toHaveProperty("overall_confidence");
      expect(result).toHaveProperty("full_trace");
      expect(result).toHaveProperty("market_regime");
    });

    it("should have reasonable confidence scores", async () => {
      const result = await quantaOrchestrator.process_query("Test", "fast");

      // Overall confidence should be reasonable
      expect(result.overall_confidence).toBeGreaterThanOrEqual(0);
      expect(result.overall_confidence).toBeLessThanOrEqual(1);

      // All trace quality scores should be valid
      for (const trace of result.full_trace) {
        expect(trace.quality_score).toBeGreaterThanOrEqual(0);
        expect(trace.quality_score).toBeLessThanOrEqual(1);
      }
    });
  });
});
