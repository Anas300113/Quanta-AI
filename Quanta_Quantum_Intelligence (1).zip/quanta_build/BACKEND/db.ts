import { eq, desc, and, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users, queries, responses, executionTraces,
  usageTracking, feedback, conversationMemory, userLearningProfile,
  type InsertQuery, type InsertResponse, type InsertExecutionTrace,
  type InsertUsageTracking,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (e) { console.warn("[DB] Failed to connect:", e); }
  }
  return _db;
}

// ==========================================
// USERS
// ==========================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("openId required");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  textFields.forEach((f) => {
    if (user[f] === undefined) return;
    values[f] = user[f] ?? null;
    updateSet[f] = user[f] ?? null;
  });

  if (user.lastSignedIn) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (!Object.keys(updateSet).length) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return r[0];
}

// ==========================================
// QUERIES & RESPONSES
// ==========================================

export async function createQuery(userId: number, query: string, problemType?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(queries).values({ userId, query, problemType });
}

export async function createResponse(
  queryId: number, finalAnswer: string, overallConfidence: number,
  agreementScore = 0, modulesUsed = "", problemType = ""
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(responses).values({
    queryId, finalAnswer,
    overallConfidence: Math.round(overallConfidence * 100),
    agreementScore: Math.round(agreementScore * 100),
    modulesUsed, problemType,
  });
}

export async function createExecutionTrace(
  responseId: number, cycle: number, decision: string,
  qualityScore: number, integratedThought?: string
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(executionTraces).values({
    responseId, cycle, decision,
    qualityScore: Math.round(qualityScore * 100), integratedThought,
  });
}

export async function getUserQueries(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(queries).where(eq(queries.userId, userId)).orderBy(desc(queries.createdAt)).limit(limit);
}

// ==========================================
// USAGE TRACKING
// ==========================================

export async function getUserUsageTracking(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(usageTracking).where(eq(usageTracking.userId, userId)).limit(1);
  return r[0] ?? null;
}

export async function updateUserUsageTracking(userId: number, queryCount: number, lastQueryAt: Date) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.update(usageTracking).set({ queryCount, lastQueryAt }).where(eq(usageTracking.userId, userId));
}

export async function initializeUserUsageTracking(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.insert(usageTracking).values({ userId, queryCount: 0, monthlyQuota: 100 })
    .onDuplicateKeyUpdate({ set: { queryCount: 0 } });
}

// ==========================================
// CONVERSATION MEMORY
// ==========================================

export async function saveToMemory(
  userId: number, userMessage: string, assistantMessage: string, qualityScore: number
) {
  const db = await getDb();
  if (!db) return;

  const truncated = assistantMessage.length > 600
    ? assistantMessage.slice(0, 597) + "..."
    : assistantMessage;

  await db.insert(conversationMemory).values({ userId, userMessage, assistantMessage: truncated, qualityScore });

  // Prune to 20 entries max
  const all = await db.select({ id: conversationMemory.id })
    .from(conversationMemory).where(eq(conversationMemory.userId, userId))
    .orderBy(desc(conversationMemory.createdAt));

  if (all.length > 20) {
    for (const entry of all.slice(20)) {
      await db.delete(conversationMemory).where(eq(conversationMemory.id, entry.id));
    }
  }
}

export async function getUserMemory(userId: number, limit = 8) {
  const db = await getDb();
  if (!db) return [];
  const r = await db.select().from(conversationMemory)
    .where(eq(conversationMemory.userId, userId))
    .orderBy(desc(conversationMemory.createdAt)).limit(limit);
  return r.reverse();
}

// ==========================================
// FEEDBACK
// ==========================================

export async function submitFeedback(
  userId: number, responseId: number, rating: boolean,
  comment: string | null, modulesUsed: string, problemType: string
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(feedback).values({ userId, responseId, rating, comment, modulesUsed, problemType });

  // Mark the most recent memory entry's sentiment
  await db.update(conversationMemory).set({ wasPositive: rating }).where(
    and(
      eq(conversationMemory.userId, userId),
      sql`${conversationMemory.createdAt} = (SELECT MAX(createdAt) FROM conversationMemory WHERE userId = ${userId})`
    )
  );
  return { success: true };
}

export async function getUserFeedback(userId: number, limit = 200) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(feedback).where(eq(feedback.userId, userId))
    .orderBy(desc(feedback.createdAt)).limit(limit);
}

// ==========================================
// LEARNING PROFILE
// ==========================================

export async function getUserLearningProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(userLearningProfile).where(eq(userLearningProfile.userId, userId)).limit(1);
  return r[0] ?? null;
}

export async function recomputeLearningProfile(userId: number) {
  const db = await getDb();
  if (!db) return;

  const allFeedback = await getUserFeedback(userId);
  if (!allFeedback.length) return;

  const totalRatings = allFeedback.length;
  const positiveRatings = allFeedback.filter((f) => f.rating).length;
  const positiveFeedback = allFeedback.filter((f) => f.rating);

  // Best agent combo from positive feedback
  const moduleCounts: Record<string, number> = {};
  for (const f of positiveFeedback) {
    const key = f.modulesUsed ?? "";
    if (key) moduleCounts[key] = (moduleCounts[key] ?? 0) + 1;
  }
  const bestPerformingModules = Object.entries(moduleCounts)
    .sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

  // Dominant problem types
  const typeCounts: Record<string, number> = {};
  for (const f of positiveFeedback) {
    const key = f.problemType ?? "General";
    typeCounts[key] = (typeCounts[key] ?? 0) + 1;
  }
  const dominantProblemTypes = Object.entries(typeCounts)
    .sort((a, b) => b[1] - a[1]).slice(0, 3).map(([t]) => t).join(",");

  // Infer depth from comment language
  const comments = allFeedback.map((f) => f.comment ?? "").join(" ").toLowerCase();
  let preferredDepth = "standard";
  if (["too long", "concise", "brief", "shorter"].some((w) => comments.includes(w))) preferredDepth = "concise";
  else if (["more detail", "expand", "deeper", "elaborate"].some((w) => comments.includes(w))) preferredDepth = "detailed";

  // Claude generates a style summary
  let learnedStyleSummary: string | null = null;
  try {
    const sampleComments = allFeedback.filter((f) => f.comment).slice(0, 5).map((f) => `"${f.comment}"`).join(", ");
    const prompt = `Write a 2-sentence summary of this user's AI response preferences for injection into future system prompts.
Data: ${totalRatings} ratings, ${positiveRatings} positive (${Math.round((positiveRatings / totalRatings) * 100)}%), preferred depth: ${preferredDepth}, top query types: ${dominantProblemTypes}, best agents: ${bestPerformingModules}, comments: ${sampleComments || "none"}.
Write as instructions starting with "This user prefers..."`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY ?? "", "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 150, messages: [{ role: "user", content: prompt }] }),
    });
    if (res.ok) {
      const d = await res.json();
      learnedStyleSummary = d.content?.[0]?.text ?? null;
    }
  } catch (e) { console.warn("[Learning] Style summary failed:", e); }

  await db.insert(userLearningProfile).values({
    userId, totalRatings, positiveRatings, preferredDepth,
    dominantProblemTypes, bestPerformingModules, learnedStyleSummary,
  }).onDuplicateKeyUpdate({
    set: { totalRatings, positiveRatings, preferredDepth, dominantProblemTypes, bestPerformingModules, learnedStyleSummary },
  });
}
