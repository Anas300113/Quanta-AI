import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { quantaOrchestrator } from "./quanta-orchestrator";
import {
  createQuery, createResponse, createExecutionTrace,
  getUserQueries, getUserUsageTracking, updateUserUsageTracking,
  initializeUserUsageTracking, saveToMemory, getUserMemory,
  getUserLearningProfile, submitFeedback, recomputeLearningProfile,
} from "./db";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  quanta: router({
    processQuery: protectedProcedure
      .input(z.object({
        query: z.string().min(1).max(2000),
        mode: z.enum(["fast", "standard"]).default("fast"),
      }))
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user.id;

        // Rate limiting
        let usage = await getUserUsageTracking(userId);
        if (!usage) { await initializeUserUsageTracking(userId); usage = await getUserUsageTracking(userId); }
        if (usage && usage.queryCount >= usage.monthlyQuota) {
          throw new Error(`Monthly quota exceeded: ${usage.queryCount}/${usage.monthlyQuota}`);
        }

        // Fetch memory and learning profile in parallel
        const [history, learningProfile] = await Promise.all([
          getUserMemory(userId, 8),
          getUserLearningProfile(userId),
        ]);

        const historyEntries = history.map((e) => ({
          userMessage: e.userMessage,
          assistantMessage: e.assistantMessage,
          wasPositive: e.wasPositive,
        }));

        const profileForOrchestrator = learningProfile ? {
          preferredDepth: learningProfile.preferredDepth,
          dominantProblemTypes: learningProfile.dominantProblemTypes,
          bestPerformingModules: learningProfile.bestPerformingModules,
          learnedStyleSummary: learningProfile.learnedStyleSummary,
        } : null;

        // Run Quanta
        const result = await quantaOrchestrator.process_query(
          input.query, input.mode, historyEntries, profileForOrchestrator
        );

        // Persist
        const queryResult = await createQuery(userId, input.query, result.problem_type);
        const queryId = (queryResult as any).insertId || 1;

        const responseResult = await createResponse(
          queryId, result.final_answer, result.overall_confidence,
          result.agreement_score, result.modules_used, result.problem_type
        );
        const responseId = (responseResult as any).insertId || 1;

        for (const trace of result.full_trace) {
          await createExecutionTrace(responseId, trace.cycle, trace.decision, trace.quality_score, trace.integrated_thought);
        }

        // Save exchange to memory
        await saveToMemory(userId, input.query, result.final_answer, result.overall_confidence);

        // Update usage
        await updateUserUsageTracking(userId, (usage?.queryCount || 0) + 1, new Date());

        return { ...result, responseId };
      }),

    submitFeedback: protectedProcedure
      .input(z.object({
        responseId: z.number(),
        rating: z.boolean(),
        comment: z.string().max(500).optional(),
        modulesUsed: z.string(),
        problemType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await submitFeedback(
          ctx.user.id, input.responseId, input.rating,
          input.comment ?? null, input.modulesUsed, input.problemType
        );
        // Recompute profile async — don't block response
        recomputeLearningProfile(ctx.user.id).catch((e) => console.error("[Learning]", e));
        return { success: true };
      }),

    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().min(1).max(100).default(20) }))
      .query(async ({ ctx, input }) => getUserQueries(ctx.user.id, input.limit)),

    getUsage: protectedProcedure
      .query(async ({ ctx }) => getUserUsageTracking(ctx.user.id)),

    getLearningProfile: protectedProcedure
      .query(async ({ ctx }) => getUserLearningProfile(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
