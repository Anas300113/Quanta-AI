/**
 * Quanta Quantum Intelligence Orchestrator
 *
 * Model routing:
 * - DeepSeek R1  → Deductive, Probabilistic (chain-of-thought reasoning)
 * - Llama 3.1    → Empirical (factual grounding, self-hosted)
 * - GPT-4o       → Analogical, Adversarial (creative + critical)
 * - Claude       → Deliberation, Synthesis (instruction-following + coherence)
 *
 * All models fall back to Claude if their key/endpoint is not configured.
 * Quanta is the engine. The models are consultants.
 */

// ==========================================
// TYPES
// ==========================================

export interface MemoryEntry {
  userMessage: string;
  assistantMessage: string;
  wasPositive?: boolean | null;
}

export interface LearningProfile {
  preferredDepth: string | null;
  dominantProblemTypes: string | null;
  bestPerformingModules: string | null;
  learnedStyleSummary: string | null;
}

export interface AgentOutput {
  agent: string;
  reasoning: string;
  answer: string;
  confidence: number;
  model: string;
}

export interface DeliberationResult {
  agreement_score: number;
  consensus_points: string[];
  conflict_points: string[];
  highest_confidence_agent: string;
}

interface ExecutionCycle {
  cycle: number;
  decision: string;
  quality_score: number;
  integrated_thought: string;
}

export interface QuantaResponse {
  query: string;
  final_answer: string;
  overall_confidence: number;
  agreement_score: number;
  agent_outputs: AgentOutput[];
  deliberation: DeliberationResult;
  full_trace: ExecutionCycle[];
  modules_used: string;
  problem_type: string;
}

// ==========================================
// MODEL CLIENTS
// ==========================================

/**
 * Claude — used for deliberation and synthesis.
 * Strongest instruction-following and coherent long-form output.
 */
async function callClaude(
  system: string,
  user: string,
  maxTokens = 1024
): Promise<string> {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY ?? "",
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${await res.text()}`);
  const d = await res.json();
  return d.content?.find((b: any) => b.type === "text")?.text ?? "";
}

/**
 * DeepSeek R1 — used for Deductive and Probabilistic agents.
 * Native chain-of-thought reasoning, strongest on structured logical tasks.
 * Falls back to Claude if DEEPSEEK_API_KEY is not set.
 */
async function callDeepSeekR1(
  system: string,
  user: string,
  maxTokens = 1024
): Promise<{ text: string; modelUsed: string }> {
  if (!process.env.DEEPSEEK_API_KEY) {
    console.warn("[Quanta] No DEEPSEEK_API_KEY — using Claude fallback for R1 slot");
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (R1 fallback)" };
  }

  try {
    const res = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.DEEPSEEK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-reasoner",
        max_tokens: maxTokens,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      }),
    });

    if (!res.ok) {
      console.warn(`[Quanta] DeepSeek R1 ${res.status} — using Claude fallback`);
      return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (R1 fallback)" };
    }

    const d = await res.json();
    // R1 returns reasoning_content (chain of thought) + content (final answer)
    // We use both — reasoning enriches the agent output, content is the answer
    const reasoning = d.choices?.[0]?.message?.reasoning_content ?? "";
    const content = d.choices?.[0]?.message?.content ?? "";
    const combined = reasoning ? `CHAIN OF THOUGHT:\n${reasoning}\n\nFINAL ANSWER:\n${content}` : content;
    return { text: combined, modelUsed: "deepseek-reasoner" };
  } catch (e) {
    console.warn("[Quanta] DeepSeek R1 error — using Claude fallback:", e);
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (R1 fallback)" };
  }
}

/**
 * Llama 3.1 (self-hosted via Ollama or vLLM) — used for Empirical agent.
 * Factual grounding on locally controlled infrastructure.
 * Falls back to Claude if LLAMA_API_URL is not set.
 *
 * To run locally: `ollama run llama3.1:70b`
 * Default Ollama endpoint: http://localhost:11434
 */
async function callLlama(
  system: string,
  user: string,
  maxTokens = 1024
): Promise<{ text: string; modelUsed: string }> {
  const baseUrl = process.env.LLAMA_API_URL;

  if (!baseUrl) {
    console.warn("[Quanta] No LLAMA_API_URL — using Claude fallback for Llama slot");
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (Llama fallback)" };
  }

  try {
    const modelName = process.env.LLAMA_MODEL ?? "llama3.1:70b";

    // Supports both Ollama (/api/chat) and OpenAI-compatible endpoints (/v1/chat/completions)
    const isOllama = baseUrl.includes("11434") || process.env.LLAMA_PROVIDER === "ollama";

    if (isOllama) {
      const res = await fetch(`${baseUrl}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: modelName,
          stream: false,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      });
      if (!res.ok) throw new Error(`Ollama ${res.status}`);
      const d = await res.json();
      return { text: d.message?.content ?? "", modelUsed: modelName };
    } else {
      // vLLM or OpenAI-compatible endpoint
      const res = await fetch(`${baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(process.env.LLAMA_API_KEY ? { Authorization: `Bearer ${process.env.LLAMA_API_KEY}` } : {}),
        },
        body: JSON.stringify({
          model: modelName,
          max_tokens: maxTokens,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      });
      if (!res.ok) throw new Error(`vLLM ${res.status}`);
      const d = await res.json();
      return { text: d.choices?.[0]?.message?.content ?? "", modelUsed: modelName };
    }
  } catch (e) {
    console.warn("[Quanta] Llama error — using Claude fallback:", e);
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (Llama fallback)" };
  }
}

/**
 * GPT-4o — used for Analogical and Adversarial agents.
 * Strong creative association and critical reasoning.
 * Falls back to Claude if OPENAI_API_KEY is not set.
 */
async function callGPT4(
  system: string,
  user: string,
  maxTokens = 1024
): Promise<{ text: string; modelUsed: string }> {
  if (!process.env.OPENAI_API_KEY) {
    console.warn("[Quanta] No OPENAI_API_KEY — using Claude fallback for GPT-4 slot");
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (GPT-4 fallback)" };
  }

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        max_tokens: maxTokens,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      }),
    });
    if (!res.ok) {
      console.warn(`[Quanta] GPT-4 ${res.status} — using Claude fallback`);
      return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (GPT-4 fallback)" };
    }
    const d = await res.json();
    return { text: d.choices?.[0]?.message?.content ?? "", modelUsed: "gpt-4o" };
  } catch (e) {
    console.warn("[Quanta] GPT-4 error — using Claude fallback:", e);
    return { text: await callClaude(system, user, maxTokens), modelUsed: "claude-sonnet-4-20250514 (GPT-4 fallback)" };
  }
}

// ==========================================
// CONTEXT BUILDERS
// ==========================================

function buildMemoryContext(history: MemoryEntry[]): string {
  if (!history.length) return "";
  const lines = history.map((e, i) => {
    const s = e.wasPositive === true ? " [helpful]" : e.wasPositive === false ? " [unhelpful]" : "";
    return `[Exchange ${i + 1}]\nUser: ${e.userMessage}\nAssistant: ${e.assistantMessage}${s}`;
  });
  return `\n\n--- CONVERSATION HISTORY ---\n${lines.join("\n\n")}\n--- END ---\n`;
}

function buildStyleInstructions(profile: LearningProfile | null): string {
  if (!profile) return "";
  const parts: string[] = [];
  if (profile.learnedStyleSummary) parts.push(profile.learnedStyleSummary);
  if (profile.preferredDepth === "concise") parts.push("Be concise. Avoid over-explaining.");
  if (profile.preferredDepth === "detailed") parts.push("Be thorough and detailed in your reasoning.");
  return parts.length ? `\n\n--- USER PREFERENCES ---\n${parts.join(" ")}\n--- END ---\n` : "";
}

function extractConfidence(text: string, fallback: number): number {
  const m = text.match(/CONFIDENCE:\s*([0-9]\.[0-9]+|[01])/i);
  if (!m) return fallback;
  const v = parseFloat(m[1]);
  return isNaN(v) ? fallback : Math.min(1, Math.max(0, v));
}

// ==========================================
// INTELLIGENCE AGENTS
// ==========================================

/**
 * DEDUCTIVE — DeepSeek R1
 * Formal logic from premises to conclusions. R1's chain-of-thought excels here.
 */
async function runDeductiveAgent(query: string, history: MemoryEntry[]): Promise<AgentOutput> {
  const system = `You are Quanta's Deductive Intelligence Agent.
Reason strictly from premises to conclusions using formal logic. Never guess.

Format:
PREMISES: [starting knowable facts]
REASONING: [step-by-step logical derivation]
CONCLUSION: [what necessarily follows]
CONFIDENCE: [0.0–1.0]
${buildMemoryContext(history)}`;

  const { text, modelUsed } = await callDeepSeekR1(system, query, 900);
  return {
    agent: "Deductive",
    reasoning: "Formal logical derivation via R1 chain-of-thought",
    answer: text,
    confidence: extractConfidence(text, 0.82),
    model: modelUsed,
  };
}

/**
 * ANALOGICAL — GPT-4o
 * Pattern matching and structural analogy. GPT-4's associative strength.
 */
async function runAnalogicalAgent(query: string, history: MemoryEntry[]): Promise<AgentOutput> {
  const system = `You are Quanta's Analogical Intelligence Agent.
Reason by identifying structural similarities to known cases and precedents.

Format:
ANALOGY: [what this resembles and why]
PATTERN: [the structural similarity]
APPLICATION: [how the pattern applies]
LIMITS: [where the analogy breaks]
CONCLUSION: [what follows]
CONFIDENCE: [0.0–1.0]
${buildMemoryContext(history)}`;

  const { text, modelUsed } = await callGPT4(system, query, 800);
  return {
    agent: "Analogical",
    reasoning: "Pattern matching and structural analogy",
    answer: text,
    confidence: extractConfidence(text, 0.78),
    model: modelUsed,
  };
}

/**
 * PROBABILISTIC — DeepSeek R1
 * Bayesian reasoning and uncertainty quantification. R1's structured reasoning is precise here.
 */
async function runProbabilisticAgent(query: string, history: MemoryEntry[]): Promise<AgentOutput> {
  const system = `You are Quanta's Probabilistic Intelligence Agent.
Reason in terms of probabilities and uncertainty. Never give false certainty.

Format:
PRIOR: [starting probability before specific context]
EVIDENCE: [what updates the estimate]
POSTERIOR: [updated probability and confidence interval]
BEST ANSWER: [most probable answer]
CONFIDENCE: [0.0–1.0]
${buildMemoryContext(history)}`;

  const { text, modelUsed } = await callDeepSeekR1(system, query, 900);
  return {
    agent: "Probabilistic",
    reasoning: "Bayesian probability and uncertainty quantification via R1",
    answer: text,
    confidence: extractConfidence(text, 0.80),
    model: modelUsed,
  };
}

/**
 * ADVERSARIAL — GPT-4o
 * Critical challenge and failure mode analysis. GPT-4's contrarian reasoning.
 */
async function runAdversarialAgent(query: string, history: MemoryEntry[]): Promise<AgentOutput> {
  const system = `You are Quanta's Adversarial Intelligence Agent.
Find what is wrong, missing, or misleading in naive answers. Steelman the opposition.

Format:
NAIVE ANSWER: [what most would say]
ATTACKS: [what is wrong with that]
EDGE CASES: [where it fails]
ROBUST ANSWER: [what a correct answer must cover]
CONFIDENCE: [0.0–1.0]
${buildMemoryContext(history)}`;

  const { text, modelUsed } = await callGPT4(system, query, 800);
  return {
    agent: "Adversarial",
    reasoning: "Critical challenge and failure mode analysis",
    answer: text,
    confidence: extractConfidence(text, 0.75),
    model: modelUsed,
  };
}

/**
 * EMPIRICAL — Llama 3.1 (self-hosted)
 * Evidence-based grounding on locally controlled infrastructure.
 * This is the agent Quanta owns most fully — runs on your hardware.
 */
async function runEmpiricalAgent(query: string, history: MemoryEntry[]): Promise<AgentOutput> {
  const system = `You are Quanta's Empirical Intelligence Agent.
Only accept claims supported by evidence. Distinguish known, inferred, and speculative.

Format:
ESTABLISHED: [empirically known facts]
INFERRED: [what reasonably follows from evidence]
SPECULATIVE: [what is uncertain or unknown]
EVIDENCE-BASED ANSWER: [grounded answer]
CONFIDENCE: [0.0–1.0]
${buildMemoryContext(history)}`;

  const { text, modelUsed } = await callLlama(system, query, 800);
  return {
    agent: "Empirical",
    reasoning: "Evidence-based analysis on self-hosted Llama infrastructure",
    answer: text,
    confidence: extractConfidence(text, 0.83),
    model: modelUsed,
  };
}

// ==========================================
// DELIBERATION LAYER — Claude
// Claude's instruction-following is best for structured JSON output
// ==========================================

async function deliberate(
  query: string,
  agentOutputs: AgentOutput[]
): Promise<DeliberationResult> {
  const summaries = agentOutputs
    .map((a) => `[${a.agent} via ${a.model} — confidence ${a.confidence.toFixed(2)}]\n${a.answer.slice(0, 350)}`)
    .join("\n\n---\n\n");

  const prompt = `Five independent reasoning agents answered this query: "${query}"

${summaries}

Analyse these outputs and respond ONLY with valid JSON — no markdown, no explanation:
{
  "agreement_score": 0.0,
  "consensus_points": ["string"],
  "conflict_points": ["string"],
  "highest_confidence_agent": "string"
}

agreement_score: 0.0 (total disagreement) to 1.0 (total agreement)
consensus_points: claims all or most agents agree on
conflict_points: claims where agents meaningfully disagree
highest_confidence_agent: name of agent with strongest reasoning for this query type`;

  try {
    const raw = await callClaude(
      "You output only valid JSON. No markdown fences, no preamble, no explanation.",
      prompt,
      500
    );
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    return {
      agreement_score: Math.min(1, Math.max(0, parsed.agreement_score ?? 0.7)),
      consensus_points: Array.isArray(parsed.consensus_points) ? parsed.consensus_points : [],
      conflict_points: Array.isArray(parsed.conflict_points) ? parsed.conflict_points : [],
      highest_confidence_agent: parsed.highest_confidence_agent ?? agentOutputs[0].agent,
    };
  } catch {
    const confidences = agentOutputs.map((a) => a.confidence);
    const mean = confidences.reduce((a, b) => a + b, 0) / confidences.length;
    const variance = confidences.reduce((s, c) => s + Math.pow(c - mean, 2), 0) / confidences.length;
    const best = agentOutputs.reduce((a, b) => (a.confidence > b.confidence ? a : b));
    return {
      agreement_score: Math.max(0, 1 - variance * 4),
      consensus_points: ["Agents reached approximate consensus"],
      conflict_points: variance > 0.05 ? ["Some variance in confidence levels"] : [],
      highest_confidence_agent: best.agent,
    };
  }
}

// ==========================================
// SYNTHESIS — Claude
// ==========================================

async function synthesise(
  query: string,
  agentOutputs: AgentOutput[],
  deliberation: DeliberationResult,
  history: MemoryEntry[],
  learningProfile: LearningProfile | null
): Promise<string> {
  const agentSummaries = agentOutputs
    .map((a) => `[${a.agent} via ${a.model} — ${(a.confidence * 100).toFixed(0)}% confidence]\n${a.answer}`)
    .join("\n\n---\n\n");

  const system = `You are Quanta — a Quantum Intelligence System.

You ran 5 independent reasoning agents across multiple AI models on this query.
Synthesise their findings into the single best possible answer.

Deliberation results:
- Inter-agent agreement: ${(deliberation.agreement_score * 100).toFixed(0)}%
- Consensus: ${deliberation.consensus_points.join("; ") || "none identified"}
- Conflicts to resolve: ${deliberation.conflict_points.join("; ") || "none"}
- Most reliable agent for this query: ${deliberation.highest_confidence_agent}

Rules:
- Weight ${deliberation.highest_confidence_agent}'s output more heavily where agents conflict
- Where agents strongly agree, state that conclusion with confidence
- Where they conflict, acknowledge the tension and give the most defensible position
- Respond as a unified intelligence — do not mention agents, models, or internal structure
- Build naturally on conversation history — never repeat prior exchanges
${buildStyleInstructions(learningProfile)}
${buildMemoryContext(history)}`;

  return callClaude(
    system,
    `Query: "${query}"\n\nAgent findings:\n${agentSummaries}`,
    1500
  );
}

// ==========================================
// PROBLEM CLASSIFIER
// ==========================================

type ProblemType =
  | "Analytical"
  | "Creative"
  | "Factual"
  | "Advisory"
  | "Technical"
  | "Philosophical"
  | "General";

function classifyProblem(query: string): ProblemType {
  const q = query.toLowerCase();
  if (["code", "bug", "function", "algorithm", "implement", "debug"].some((w) => q.includes(w))) return "Technical";
  if (["should i", "recommend", "strategy", "plan", "advise", "best way"].some((w) => q.includes(w))) return "Advisory";
  if (["analyse", "analyze", "compare", "evaluate", "assess"].some((w) => q.includes(w))) return "Analytical";
  if (["write", "create", "generate", "draft", "brainstorm"].some((w) => q.includes(w))) return "Creative";
  if (["what is", "who is", "when", "where", "define", "explain", "how does"].some((w) => q.includes(w))) return "Factual";
  if (["why", "meaning", "purpose", "ethical", "moral", "philosophy"].some((w) => q.includes(w))) return "Philosophical";
  return "General";
}

function selectAgents(type: ProblemType, profile: LearningProfile | null): string[] {
  // Use learned best combo if available
  if (profile?.bestPerformingModules) {
    const learned = profile.bestPerformingModules.split(",").map((m) => m.trim()).filter(Boolean);
    if (learned.length >= 3) {
      console.log(`[Quanta] Using learned agent combo: ${learned.join(", ")}`);
      return learned;
    }
  }

  switch (type) {
    case "Technical":     return ["Deductive", "Adversarial", "Empirical"];
    case "Advisory":      return ["Analogical", "Probabilistic", "Adversarial"];
    case "Analytical":    return ["Deductive", "Probabilistic", "Adversarial", "Empirical"];
    case "Creative":      return ["Analogical", "Probabilistic", "Empirical"];
    case "Philosophical": return ["Deductive", "Analogical", "Probabilistic", "Adversarial", "Empirical"];
    default:              return ["Deductive", "Analogical", "Probabilistic", "Adversarial", "Empirical"];
  }
}

// ==========================================
// MAIN ORCHESTRATOR
// ==========================================

const AGENTS: Record<string, (q: string, h: MemoryEntry[]) => Promise<AgentOutput>> = {
  Deductive:     runDeductiveAgent,
  Analogical:    runAnalogicalAgent,
  Probabilistic: runProbabilisticAgent,
  Adversarial:   runAdversarialAgent,
  Empirical:     runEmpiricalAgent,
};

export class QuantaOrchestrator {
  async process_query(
    query: string,
    mode = "fast",
    conversationHistory: MemoryEntry[] = [],
    learningProfile: LearningProfile | null = null
  ): Promise<QuantaResponse> {
    const t0 = Date.now();
    const problemType = classifyProblem(query);
    const selectedAgents = selectAgents(problemType, learningProfile);

    console.log(`[Quanta] "${query.slice(0, 55)}..."`);
    console.log(`[Quanta] Type: ${problemType} | Agents: ${selectedAgents.join(", ")}`);
    console.log(`[Quanta] History: ${conversationHistory.length} | Profile: ${!!learningProfile}`);

    // All selected agents run in parallel across their respective models
    const agentOutputs = await Promise.all(
      selectedAgents.filter((n) => n in AGENTS).map((n) => AGENTS[n](query, conversationHistory))
    );

    // Log which model each agent actually used (may be fallback)
    agentOutputs.forEach((a) => console.log(`[Quanta] ${a.agent}: ${a.model} (${(a.confidence * 100).toFixed(0)}%)`));

    // Claude deliberates on all agent outputs
    const deliberation = await deliberate(query, agentOutputs);

    // Claude synthesises the final answer
    const finalAnswer = await synthesise(query, agentOutputs, deliberation, conversationHistory, learningProfile);

    // Confidence = 60% avg agent confidence + 40% inter-agent agreement
    const avgConfidence = agentOutputs.reduce((s, a) => s + a.confidence, 0) / agentOutputs.length;
    const overallConfidence = avgConfidence * 0.6 + deliberation.agreement_score * 0.4;

    console.log(`[Quanta] Done in ${Date.now() - t0}ms | Confidence: ${(overallConfidence * 100).toFixed(1)}% | Agreement: ${(deliberation.agreement_score * 100).toFixed(0)}%`);

    return {
      query,
      final_answer: finalAnswer,
      overall_confidence: overallConfidence,
      agreement_score: deliberation.agreement_score,
      agent_outputs: agentOutputs,
      deliberation,
      full_trace: [{
        cycle: 1,
        decision: overallConfidence > 0.75 ? "Conclude" : "Low confidence — caveats applied",
        quality_score: overallConfidence,
        integrated_thought: `${selectedAgents.length} agents across 4 models | Type: ${problemType} | Agreement: ${(deliberation.agreement_score * 100).toFixed(0)}%`,
      }],
      modules_used: selectedAgents.join(","),
      problem_type: problemType,
    };
  }
}

export const quantaOrchestrator = new QuantaOrchestrator();
