# Quanta AI Platform - Quick Start (5 Minutes)

Get the Quanta AI platform running in 5 minutes.

## Prerequisites

- Node.js 18+ ([Download](https://nodejs.org/))
- MySQL 8.0+ ([Download](https://dev.mysql.com/downloads/mysql/))
- npm or pnpm

## Step 1: Setup (1 minute)

```bash
# Navigate to SETUP directory
cd SETUP

# Make install script executable
chmod +x install_dependencies.sh

# Run installer
./install_dependencies.sh

# Copy environment template
cp environment_template.env ../.env

# Edit .env with your database credentials
nano ../.env
```

## Step 2: Database (1 minute)

```bash
# Connect to MySQL
mysql -u root -p

# Run this in MySQL shell:
CREATE DATABASE quanta_ai;
USE quanta_ai;
SOURCE ../DATABASE/schema.sql;
EXIT;
```

## Step 3: Backend (1 minute)

```bash
# Navigate to backend
cd ../BACKEND

# Install dependencies
npm install

# Start backend server
npm run dev

# You should see: "Server running on http://localhost:3000/"
```

## Step 4: Frontend (1 minute)

In a new terminal:

```bash
# Navigate to frontend
cd FRONTEND

# Install dependencies
npm install

# Start frontend server
npm run dev

# You should see: "VITE v... ready in ... ms"
```

## Step 5: Access the Platform (1 minute)

Open your browser and navigate to:

- **Landing Page**: http://localhost:3000
- **Chat Interface**: http://localhost:3000/app
- **Admin Dashboard**: http://localhost:3000/admin (requires admin login)
- **Founder Control**: http://localhost:3000/founder (requires founder login)

## ✅ You're Done!

The platform is now running. Try:

1. Click "Try Now" on the landing page
2. Submit a query in the chat interface
3. View execution traces and confidence scores
4. Check the admin dashboard for metrics

## 🔧 Troubleshooting

**Port already in use?**
```bash
# Kill process using port 3000
lsof -i :3000
kill -9 <PID>
```

**Database connection failed?**
```bash
# Verify MySQL is running
mysql -u root -p

# Check DATABASE_URL in .env
cat .env | grep DATABASE_URL
```

**Tests failing?**
```bash
# Run backend tests
cd BACKEND
npm test
```

## 📚 Next Steps

1. Read `ASSEMBLY_GUIDE.md` for detailed setup
2. Check `DOCUMENTATION/API_REFERENCE.md` for API details
3. Review `DOCUMENTATION/TROUBLESHOOTING.md` for common issues
4. Customize branding in `FRONTEND/index.css`
5. Deploy to production (see `DOCUMENTATION/DEPLOYMENT.md`)

## 🎯 Quick Commands Reference

```bash
# Start backend
cd BACKEND && npm run dev

# Start frontend
cd FRONTEND && npm run dev

# Run tests
cd BACKEND && npm test

# Build for production
npm run build

# Check TypeScript
npm run check

# Format code
npm run format

# Database migrations
npm run db:push
```

## 📞 Need Help?

- Check `DOCUMENTATION/TROUBLESHOOTING.md`
- Review error messages carefully
- Check backend logs in terminal
- Open browser DevTools (F12) for frontend errors
- Contact support@quanta.ai

---

**Congratulations! Your Quanta AI platform is ready to use.** 🚀
