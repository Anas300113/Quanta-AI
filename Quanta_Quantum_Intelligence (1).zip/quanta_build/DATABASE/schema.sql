-- Quanta AI Platform - Database Schema
-- Run this file to initialize the database

-- Create database
CREATE DATABASE IF NOT EXISTS quanta_ai;
USE quanta_ai;

-- ==========================================
-- USERS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  openId VARCHAR(64) NOT NULL UNIQUE,
  name TEXT,
  email VARCHAR(320),
  loginMethod VARCHAR(64),
  role ENUM('user', 'admin') DEFAULT 'user' NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  lastSignedIn TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  INDEX idx_openId (openId),
  INDEX idx_email (email)
);

-- ==========================================
-- QUERIES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS queries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  content TEXT NOT NULL,
  queryType VARCHAR(100),
  mode ENUM('fast', 'standard', 'deep') DEFAULT 'standard',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_userId (userId),
  INDEX idx_createdAt (createdAt)
);

-- ==========================================
-- RESPONSES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS responses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  queryId INT NOT NULL,
  userId INT NOT NULL,
  content LONGTEXT NOT NULL,
  confidenceScore DECIMAL(5, 2),
  confidenceBound DECIMAL(5, 2),
  qualityScore DECIMAL(5, 2),
  processingTimeMs INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (queryId) REFERENCES queries(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_queryId (queryId),
  INDEX idx_userId (userId),
  INDEX idx_createdAt (createdAt)
);

-- ==========================================
-- EXECUTION TRACES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS execution_traces (
  id INT AUTO_INCREMENT PRIMARY KEY,
  responseId INT NOT NULL,
  cycleNumber INT,
  moduleName VARCHAR(100),
  decision VARCHAR(50),
  qualityScore DECIMAL(5, 2),
  reasoning TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (responseId) REFERENCES responses(id) ON DELETE CASCADE,
  INDEX idx_responseId (responseId),
  INDEX idx_moduleName (moduleName)
);

-- ==========================================
-- METRICS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS metrics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  metricType VARCHAR(100),
  value DECIMAL(10, 2),
  userId INT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  metadata JSON,
  INDEX idx_metricType (metricType),
  INDEX idx_userId (userId),
  INDEX idx_timestamp (timestamp)
);

-- ==========================================
-- USAGE TRACKING TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS usage_tracking (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT NOT NULL,
  queriesThisMonth INT DEFAULT 0,
  tokensUsedThisMonth INT DEFAULT 0,
  quotaLimit INT DEFAULT 1000,
  lastResetDate DATE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_userId (userId),
  UNIQUE KEY unique_user_month (userId, lastResetDate)
);

-- ==========================================
-- FLAGGED CONTENT TABLE (Moderation)
-- ==========================================
CREATE TABLE IF NOT EXISTS flagged_content (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT,
  content LONGTEXT,
  reason VARCHAR(255),
  status ENUM('pending', 'reviewed', 'approved', 'blocked') DEFAULT 'pending',
  reviewedBy INT,
  reviewedAt TIMESTAMP NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (reviewedBy) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_userId (userId),
  INDEX idx_createdAt (createdAt)
);

-- ==========================================
-- SYSTEM HEALTH TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS system_health (
  id INT AUTO_INCREMENT PRIMARY KEY,
  componentName VARCHAR(100),
  status ENUM('healthy', 'warning', 'error') DEFAULT 'healthy',
  cpuUsage DECIMAL(5, 2),
  memoryUsage DECIMAL(5, 2),
  gpuUtilization DECIMAL(5, 2),
  responseTimeMs INT,
  errorCount INT DEFAULT 0,
  lastChecked TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_componentName (componentName),
  INDEX idx_lastChecked (lastChecked)
);

-- ==========================================
-- SESSIONS TABLE (for authentication)
-- ==========================================
CREATE TABLE IF NOT EXISTS sessions (
  id VARCHAR(255) PRIMARY KEY,
  userId INT NOT NULL,
  token VARCHAR(500),
  expiresAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_userId (userId),
  INDEX idx_expiresAt (expiresAt)
);

-- ==========================================
-- INDEXES FOR PERFORMANCE
-- ==========================================
CREATE INDEX idx_queries_user_created ON queries(userId, createdAt DESC);
CREATE INDEX idx_responses_user_created ON responses(userId, createdAt DESC);
CREATE INDEX idx_metrics_type_time ON metrics(metricType, timestamp DESC);

-- ==========================================
-- VIEWS FOR ANALYTICS
-- ==========================================

-- Daily query volume
CREATE OR REPLACE VIEW daily_query_volume AS
SELECT 
  DATE(createdAt) as date,
  COUNT(*) as query_count,
  COUNT(DISTINCT userId) as unique_users
FROM queries
GROUP BY DATE(createdAt)
ORDER BY date DESC;

-- Module usage statistics
CREATE OR REPLACE VIEW module_usage_stats AS
SELECT 
  moduleName,
  COUNT(*) as usage_count,
  AVG(qualityScore) as avg_quality,
  COUNT(CASE WHEN decision = 'Refine' THEN 1 END) as refine_count
FROM execution_traces
GROUP BY moduleName
ORDER BY usage_count DESC;

-- User activity summary
CREATE OR REPLACE VIEW user_activity_summary AS
SELECT 
  u.id,
  u.name,
  u.email,
  COUNT(DISTINCT q.id) as total_queries,
  AVG(r.confidenceScore) as avg_confidence,
  MAX(q.createdAt) as last_query_date
FROM users u
LEFT JOIN queries q ON u.id = q.userId
LEFT JOIN responses r ON q.id = r.queryId
GROUP BY u.id, u.name, u.email;

-- ==========================================
-- INITIAL DATA (Optional)
-- ==========================================

-- Create admin user (change credentials in production)
INSERT IGNORE INTO users (openId, name, email, loginMethod, role)
VALUES ('admin_user_001', 'Admin User', 'admin@quanta.ai', 'internal', 'admin');

-- ==========================================
-- DONE
-- ==========================================
-- Database schema initialized successfully!
-- You can now connect your application.
