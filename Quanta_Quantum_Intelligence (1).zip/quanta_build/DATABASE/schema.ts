import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const queries = mysqlTable("queries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  query: text("query").notNull(),
  problemType: varchar("problemType", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Query = typeof queries.$inferSelect;
export type InsertQuery = typeof queries.$inferInsert;

export const responses = mysqlTable("responses", {
  id: int("id").autoincrement().primaryKey(),
  queryId: int("queryId").notNull().references(() => queries.id),
  finalAnswer: text("finalAnswer").notNull(),
  overallConfidence: int("overallConfidence").notNull(),
  agreementScore: int("agreementScore").default(0).notNull(),
  modulesUsed: varchar("modulesUsed", { length: 256 }),
  problemType: varchar("problemType", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Response = typeof responses.$inferSelect;
export type InsertResponse = typeof responses.$inferInsert;

export const executionTraces = mysqlTable("executionTraces", {
  id: int("id").autoincrement().primaryKey(),
  responseId: int("responseId").notNull().references(() => responses.id),
  cycle: int("cycle").notNull(),
  decision: varchar("decision", { length: 128 }).notNull(),
  qualityScore: int("qualityScore").notNull(),
  integratedThought: text("integratedThought"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ExecutionTrace = typeof executionTraces.$inferSelect;
export type InsertExecutionTrace = typeof executionTraces.$inferInsert;

export const usageTracking = mysqlTable("usageTracking", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id).unique(),
  queryCount: int("queryCount").default(0).notNull(),
  monthlyQuota: int("monthlyQuota").default(100).notNull(),
  lastQueryAt: timestamp("lastQueryAt"),
  lastResetAt: timestamp("lastResetAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type UsageTracking = typeof usageTracking.$inferSelect;
export type InsertUsageTracking = typeof usageTracking.$inferInsert;

// ==========================================
// FEEDBACK
// ==========================================
export const feedback = mysqlTable("feedback", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  responseId: int("responseId").notNull().references(() => responses.id),
  rating: boolean("rating").notNull(),
  comment: text("comment"),
  modulesUsed: varchar("modulesUsed", { length: 256 }),
  problemType: varchar("problemType", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = typeof feedback.$inferInsert;

// ==========================================
// CONVERSATION MEMORY
// ==========================================
export const conversationMemory = mysqlTable("conversationMemory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  userMessage: text("userMessage").notNull(),
  assistantMessage: text("assistantMessage").notNull(),
  qualityScore: float("qualityScore").default(0).notNull(),
  wasPositive: boolean("wasPositive"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ConversationMemory = typeof conversationMemory.$inferSelect;
export type InsertConversationMemory = typeof conversationMemory.$inferInsert;

// ==========================================
// USER LEARNING PROFILE
// ==========================================
export const userLearningProfile = mysqlTable("userLearningProfile", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id).unique(),
  totalRatings: int("totalRatings").default(0).notNull(),
  positiveRatings: int("positiveRatings").default(0).notNull(),
  preferredDepth: varchar("preferredDepth", { length: 32 }).default("standard"),
  dominantProblemTypes: varchar("dominantProblemTypes", { length: 256 }),
  bestPerformingModules: varchar("bestPerformingModules", { length: 256 }),
  avgPositiveConfidence: float("avgPositiveConfidence").default(0),
  learnedStyleSummary: text("learnedStyleSummary"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type UserLearningProfile = typeof userLearningProfile.$inferSelect;
export type InsertUserLearningProfile = typeof userLearningProfile.$inferInsert;
